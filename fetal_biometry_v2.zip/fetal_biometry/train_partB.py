"""
train_partB.py
==============
Train the Attention U-Net segmentation model (Part B).

Usage:
    python train_partB.py
    python train_partB.py --epochs 50 --batch 4 --lr 3e-4
"""

import argparse
import os
import pandas as pd
import torch

import config as cfg
from src.shared.dataset import SegmentationDataset, build_dataloaders
from src.partB.model import AttentionUNet, DiceBCELoss
from src.partB.trainer import train, evaluate, visualise, plot_history


def parse_args():
    p = argparse.ArgumentParser(description="Train Part B — Segmentation")
    p.add_argument("--data_dir",   default=cfg.DATA_DIR)
    p.add_argument("--mask_dir",   default=cfg.MASK_DIR)
    p.add_argument("--annot_csv",  default=cfg.ANNOT_CSV)
    p.add_argument("--output_dir", default=cfg.OUTPUT_DIR_B)
    p.add_argument("--epochs",     type=int,   default=cfg.NUM_EPOCHS)
    p.add_argument("--batch",      type=int,   default=cfg.SEG_BATCH)
    p.add_argument("--lr",         type=float, default=cfg.LR)
    p.add_argument("--eval_only",  action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    cfg.NUM_EPOCHS   = args.epochs
    cfg.SEG_BATCH    = args.batch
    cfg.LR           = args.lr
    cfg.OUTPUT_DIR_B = args.output_dir
    os.makedirs(cfg.OUTPUT_DIR_B, exist_ok=True)

    model_path = os.path.join(cfg.OUTPUT_DIR_B, "best_seg_model.pth")

    # ── 1. Load data ──────────────────────────────────────────────────────
    print("\n[1/4] Loading dataset...")
    df = pd.read_csv(args.annot_csv)
    # No outlier filter for Part B — masks exist for all 622 images
    df = df.sample(frac=1, random_state=cfg.RANDOM_SEED).reset_index(drop=True)
    print(f"  Total samples: {len(df)}")

    # ── 2. Dataloaders ────────────────────────────────────────────────────
    print("\n[2/4] Building dataloaders...")
    train_dl, val_dl, train_df, val_df = build_dataloaders(
        SegmentationDataset, df, args.data_dir, args.mask_dir,
        batch_size=cfg.SEG_BATCH
    )

    # ── 3. Model ──────────────────────────────────────────────────────────
    print("\n[3/4] Initialising model...")
    model = AttentionUNet().to(cfg.DEVICE)
    print(f"  Trainable parameters: {model.count_parameters():,}")
    print(f"  Device: {cfg.DEVICE}")

    # ── 4. Train ──────────────────────────────────────────────────────────
    if not args.eval_only:
        print("\n[4/4] Training...")
        loss_fn = DiceBCELoss(pos_weight=cfg.POS_WEIGHT)
        history = train(model, train_dl, val_dl, loss_fn, model_path)
        plot_history(history, os.path.join(cfg.OUTPUT_DIR_B, "train_curves.png"))
        print(f"\n  Training curves saved → {cfg.OUTPUT_DIR_B}/train_curves.png")

    # ── 5. Evaluate ───────────────────────────────────────────────────────
    if os.path.exists(model_path):
        print("\n[EVAL] Loading best model and evaluating...")
        model.load_state_dict(torch.load(model_path, map_location=cfg.DEVICE))
        metrics = evaluate(model, val_df, args.data_dir, args.mask_dir)

        # Save metrics JSON
        import json, numpy as np
        summary = {k: {"mean": float(v.mean()), "std": float(v.std())}
                   for k, v in metrics.items()}
        with open(os.path.join(cfg.OUTPUT_DIR_B, "eval_metrics.json"), "w") as f:
            json.dump(summary, f, indent=2)
        print(f"  Metrics saved → {cfg.OUTPUT_DIR_B}/eval_metrics.json")

        # Visualise samples
        print("\n[VIZ] Generating sample predictions...")
        for _, row in val_df.head(4).iterrows():
            img_path = os.path.join(args.data_dir, row[cfg.IMG_COL])
            if not os.path.exists(img_path):
                continue
            try:
                from src.partB.trainer import predict
                result = predict(model, img_path)
                if "error" in result:
                    continue
            except Exception as e:
                print(f"  Skipped {row[cfg.IMG_COL]}: {e}")
                continue
            save = os.path.join(cfg.OUTPUT_DIR_B, f"pred_{row[cfg.IMG_COL]}")
            visualise(img_path, result, gt_row=row, save_path=save)
            print(f"  Saved → {save}")
    else:
        print(f"\n  No model at {model_path}. Run without --eval_only first.")

    print("\n✓ Part B complete.")


if __name__ == "__main__":
    main()
