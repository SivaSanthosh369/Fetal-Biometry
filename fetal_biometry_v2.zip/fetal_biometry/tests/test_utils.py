"""
tests/test_utils.py
Unit tests for shared utilities (no GPU required).
Run with: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pytest
import torch

import config as cfg
from src.shared.utils import (
    apply_clahe, make_heatmap, heatmap_to_coord,
    fit_ellipse_to_mask, ellipse_to_landmarks,
    compute_measurements, euclidean,
    dice_score, filter_outliers
)


# ─────────────────────────────────────────────────────────────────────────────
# PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────

class TestPreprocessing:
    def test_clahe_output_shape(self):
        img = np.random.randint(0, 256, (540, 800), dtype=np.uint8)
        out = apply_clahe(img)
        assert out.shape == img.shape, "CLAHE should not change image shape"

    def test_clahe_output_range(self):
        img = np.random.randint(0, 256, (540, 800), dtype=np.uint8)
        out = apply_clahe(img)
        assert out.min() >= 0 and out.max() <= 255


# ─────────────────────────────────────────────────────────────────────────────
# HEATMAPS
# ─────────────────────────────────────────────────────────────────────────────

class TestHeatmaps:
    def test_heatmap_shape(self):
        hm = make_heatmap(32.0, 32.0, H=64, W=64, sigma=3)
        assert hm.shape == (64, 64)

    def test_heatmap_peak_location(self):
        x, y = 20.0, 30.0
        hm = make_heatmap(x, y, H=64, W=64, sigma=2)
        px, py = heatmap_to_coord(hm)
        assert abs(px - x) <= 2, f"Peak x off: expected {x}, got {px}"
        assert abs(py - y) <= 2, f"Peak y off: expected {y}, got {py}"

    def test_heatmap_max_is_one(self):
        hm = make_heatmap(16.0, 16.0, H=32, W=32, sigma=2)
        assert abs(hm.max() - 1.0) < 1e-5

    def test_heatmap_out_of_bounds(self):
        # Point outside heatmap — should return all-zeros without crashing
        hm = make_heatmap(-10.0, -10.0, H=64, W=64, sigma=3)
        assert hm.max() == 0.0

    def test_coord_roundtrip(self):
        for x, y in [(10, 10), (32, 48), (63, 1)]:
            hm = make_heatmap(float(x), float(y), H=64, W=64, sigma=2)
            px, py = heatmap_to_coord(hm)
            assert abs(px - x) <= 2
            assert abs(py - y) <= 2


# ─────────────────────────────────────────────────────────────────────────────
# ELLIPSE
# ─────────────────────────────────────────────────────────────────────────────

class TestEllipse:
    def _make_ellipse_mask(self, h=256, w=256, cx=128, cy=128,
                           axes=(80, 60), angle=30):
        import cv2
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.ellipse(mask, (cx, cy), axes, angle, 0, 360, 255, 2)
        return mask

    def test_fit_ellipse_returns_params(self):
        mask = self._make_ellipse_mask()
        result = fit_ellipse_to_mask(mask)
        assert result is not None, "fit_ellipse_to_mask should succeed on clean ellipse"
        cx, cy, mn, mj, ang = result
        assert abs(cx - 128) < 10
        assert abs(cy - 128) < 10

    def test_fit_ellipse_empty_mask(self):
        mask = np.zeros((256, 256), dtype=np.uint8)
        result = fit_ellipse_to_mask(mask)
        assert result is None

    def test_ellipse_to_landmarks_keys(self):
        mask = self._make_ellipse_mask()
        ell  = fit_ellipse_to_mask(mask)
        assert ell is not None
        cx, cy, mn, mj, ang = ell
        lm = ellipse_to_landmarks(cx, cy, mn, mj, ang,
                                   model_h=256, model_w=256,
                                   orig_h=540, orig_w=800)
        assert set(lm.keys()) == {"BPD_1", "BPD_2", "OFD_1", "OFD_2"}

    def test_ellipse_landmarks_in_image(self):
        mask = self._make_ellipse_mask()
        ell  = fit_ellipse_to_mask(mask)
        cx, cy, mn, mj, ang = ell
        lm = ellipse_to_landmarks(cx, cy, mn, mj, ang,
                                   model_h=256, model_w=256,
                                   orig_h=540, orig_w=800)
        for name, (x, y) in lm.items():
            assert 0 <= x <= 800, f"{name} x={x} out of bounds"
            assert 0 <= y <= 540, f"{name} y={y} out of bounds"


# ─────────────────────────────────────────────────────────────────────────────
# MEASUREMENTS
# ─────────────────────────────────────────────────────────────────────────────

class TestMeasurements:
    def test_euclidean(self):
        assert abs(euclidean((0,0), (3,4)) - 5.0) < 1e-6
        assert abs(euclidean((1,1), (1,1)) - 0.0) < 1e-6

    def test_compute_measurements_pixels_only(self):
        lm = {"BPD_1": (0,0), "BPD_2": (100,0),
              "OFD_1": (0,0), "OFD_2": (0,150)}
        m = compute_measurements(lm)
        assert abs(m["BPD_px"] - 100.0) < 1e-5
        assert abs(m["OFD_px"] - 150.0) < 1e-5
        assert "BPD_mm" not in m

    def test_compute_measurements_with_spacing(self):
        lm = {"BPD_1": (0,0), "BPD_2": (100,0),
              "OFD_1": (0,0), "OFD_2": (0,150)}
        m = compute_measurements(lm, pixel_spacing_mm=0.2)
        assert abs(m["BPD_mm"] - 20.0) < 1e-5
        assert abs(m["OFD_mm"] - 30.0) < 1e-5
        assert "HC_mm" in m
        # HC = 1.62 * (20+30)/2 = 40.5
        assert abs(m["HC_mm"] - 40.5) < 1e-4


# ─────────────────────────────────────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────────────────────────────────────

class TestMetrics:
    def test_dice_perfect(self):
        a = np.ones((10, 10))
        assert abs(dice_score(a, a) - 1.0) < 1e-5

    def test_dice_empty(self):
        a = np.zeros((10, 10))
        d = dice_score(a, a)
        assert 0 <= d <= 1

    def test_dice_half_overlap(self):
        pred   = np.zeros((10, 10)); pred[:5, :] = 1
        target = np.zeros((10, 10)); target[5:, :] = 1
        d = dice_score(pred, target)
        assert d < 0.1   # no overlap → near 0


# ─────────────────────────────────────────────────────────────────────────────
# DATA VALIDATION
# ─────────────────────────────────────────────────────────────────────────────

class TestDataValidation:
    def test_filter_outliers_removes_small_dists(self):
        import pandas as pd
        df = pd.DataFrame({
            "image_name": ["good.png", "bad.png"],
            "bpd_1_x": [0,   0], "bpd_1_y": [0,  0],
            "bpd_2_x": [300, 10], "bpd_2_y": [0, 0],
            "ofd_1_x": [0,   0], "ofd_1_y": [0,  0],
            "ofd_2_x": [400, 5], "ofd_2_y": [0, 0],
        })
        clean = filter_outliers(df, min_dist_px=50)
        assert len(clean) == 1
        assert clean.iloc[0]["image_name"] == "good.png"


# ─────────────────────────────────────────────────────────────────────────────
# MODEL SHAPES (CPU only, no training)
# ─────────────────────────────────────────────────────────────────────────────

class TestModelShapes:
    def test_landmarknet_output_shape(self):
        from src.partA.model import LandmarkNet
        model = LandmarkNet(n_landmarks=4)
        x   = torch.randn(2, 1, 256, 256)
        out = model(x)
        assert out.shape == (2, 4, 64, 64), f"Unexpected shape: {out.shape}"

    def test_landmarknet_output_range(self):
        from src.partA.model import LandmarkNet
        model = LandmarkNet(n_landmarks=4)
        x   = torch.randn(1, 1, 256, 256)
        out = model(x)
        assert out.min() >= 0.0 and out.max() <= 1.0, "Output should be in [0,1] after sigmoid"

    def test_attention_unet_output_shape(self):
        from src.partB.model import AttentionUNet
        model = AttentionUNet()
        x   = torch.randn(2, 1, 256, 256)
        out = model(x)
        assert out.shape == (2, 1, 256, 256), f"Unexpected shape: {out.shape}"

    def test_dice_bce_loss(self):
        from src.partB.model import DiceBCELoss
        loss_fn = DiceBCELoss()
        pred = torch.randn(2, 1, 64, 64)
        gt   = (torch.randn(2, 1, 64, 64) > 0).float()
        loss = loss_fn(pred, gt)
        assert loss.item() > 0, "Loss should be positive"

    def test_adaptive_wing_loss(self):
        from src.partA.model import AdaptiveWingLoss
        loss_fn = AdaptiveWingLoss()
        pred = torch.rand(2, 4, 64, 64)
        gt   = torch.rand(2, 4, 64, 64)
        loss = loss_fn(pred, gt)
        assert loss.item() > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
