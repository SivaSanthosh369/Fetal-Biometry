# Fetal Biometry — BPD & OFD Landmark Detection
### Complete Algorithm Package for Fetal Axial Ultrasound Analysis

---

## Project Overview

Automated detection of **Biparietal Diameter (BPD)** and **Occipitofrontal Diameter (OFD)** landmark points from fetal axial ultrasound images. Used clinically to estimate gestational age, fetal growth, and head circumference (HC).

```
BPD:  Points BPD_1 & BPD_2  (widest transverse diameter — parietal to parietal)
OFD:  Points OFD_1 & OFD_2  (anteroposterior diameter — occiput to frontal bone)
HC ≈  1.62 × (BPD + OFD) / 2   (Hadlock approximation)
```

---

## Two Approaches

| | Part A — Landmark Detection | Part B — Segmentation |
|---|---|---|
| **Strategy** | Direct heatmap regression | Segment skull → fit ellipse → extract axis endpoints |
| **Model** | EfficientNet-B3 + decoder | Attention U-Net |
| **Loss** | Adaptive Wing Loss | Dice + Weighted BCE |
| **Data needed** | 4 landmark coords per image | Binary skull outline masks |
| **Expected MRE** | ~1.5–2.5 mm | ~1.5–3.0 mm |
| **Expected Dice** | N/A | ~0.97–0.98 |

---

## Dataset Facts (HC18 / Role Challenge)

| Property | Value |
|---|---|
| Total samples | 622 images |
| Image size | 540×800 px (majority) |
| Ground truth CSV | `image_name, ofd_1_x/y, ofd_2_x/y, bpd_1_x/y, bpd_2_x/y` |
| Masks | Binary ellipse outlines, ~0.7% foreground pixels |
| Outliers | 11 images with annotation errors (auto-filtered) |
| Pixel spacing | ~0.168 mm/px (varies; use DICOM PixelSpacing if available) |

---

## Project Structure

```
fetal_biometry/
├── config.py                    ← All settings (edit this first)
├── train_partA.py               ← Train landmark detection model
├── train_partB.py               ← Train segmentation model
├── predict.py                   ← Run inference on new images
├── explore_dataset.py           ← EDA and data validation
├── requirements.txt
│
├── src/
│   ├── shared/
│   │   ├── utils.py             ← CLAHE, heatmaps, ellipse, metrics
│   │   └── dataset.py           ← Dataset classes, augmentation, loaders
│   ├── partA/
│   │   ├── model.py             ← LandmarkNet + AdaptiveWingLoss
│   │   └── trainer.py           ← Train, evaluate, predict, visualise
│   └── partB/
│       ├── model.py             ← AttentionUNet + DiceBCELoss
│       └── trainer.py           ← Train, evaluate, predict, visualise
│
├── tests/
│   └── test_utils.py            ← Unit tests (pytest)
│
├── data/                        ← Place your dataset here
│   ├── training_set/            ← HC ultrasound PNG images
│   ├── masks/                   ← *_Annotation.png mask files
│   └── ground_truth.csv         ← role_challenge_dataset_ground_truth.csv
│
└── outputs/
    ├── partA/                   ← Part A model weights, curves, predictions
    └── partB/                   ← Part B model weights, curves, predictions
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Prepare data
```bash
# Place your files:
cp role_challenge_dataset_ground_truth.csv  data/ground_truth.csv
cp -r training_set/                          data/training_set/
cp -r masks/                                 data/masks/
```

### 3. Explore dataset (recommended)
```bash
python explore_dataset.py
# → outputs/annotation_dashboard.png  (9-panel analysis)
# → outputs/dataset_stats.json
# → outputs/train_split.csv  +  val_split.csv
```

### 4. Train Part A — Landmark Detection
```bash
python train_partA.py
# With custom settings:
python train_partA.py --epochs 80 --batch 8 --lr 5e-5
```

### 5. Train Part B — Segmentation
```bash
python train_partB.py
# With custom settings:
python train_partB.py --epochs 50 --batch 4
```

### 6. Run inference on new images
```bash
# Single image
python predict.py --model partA --image test_image.png
python predict.py --model partB --image test_image.png

# Batch folder
python predict.py --model partA --image_dir ./test_images --output_dir ./results

# With pixel spacing from DICOM
python predict.py --model partB --image scan.dcm --pixel_spacing 0.152
```

### 7. Run tests
```bash
python -m pytest tests/ -v
```

---

## Configuration

All settings live in `config.py`. Key parameters:

```python
DATA_DIR   = "./data/training_set"   # ultrasound images
MASK_DIR   = "./data/masks"          # annotation masks (Part B)
ANNOT_CSV  = "./data/ground_truth.csv"

INPUT_SIZE       = 256      # model input resolution
HEATMAP_SIZE     = 64       # Part A output heatmap size
SIGMA            = 3.0      # GT Gaussian sigma
PIXEL_SPACING_MM = 0.168    # override per-image from DICOM if available

BATCH_SIZE  = 16   # reduce to 8 or 4 if GPU OOM
NUM_EPOCHS  = 60
LR          = 1e-4
```

---

## Architecture Details

### Part A — LandmarkNet

```
Input (1, 256, 256)
   ↓
EfficientNet-B3 features [pretrained, 1-ch adapted]
   ↓  (1536, 8, 8)
ConvTranspose2d → (256, 16, 16)
ConvTranspose2d → (128, 32, 32)
ConvTranspose2d → (64,  64, 64)
Conv2d 1×1      → (4,   64, 64)
Sigmoid
   ↓
4 Heatmaps [OFD_1 | OFD_2 | BPD_1 | BPD_2]
   ↓
argmax → (x, y) coordinates → scale to original image → mm
```

**Loss: Adaptive Wing Loss** (Wang et al., ICCV 2019)
- Better than MSE for heatmap regression: penalises small errors near the Gaussian peak more aggressively
- Parameters: ω=14, θ=0.5, ε=1.0, α=2.1

### Part B — AttentionUNet

```
Input (1, 256, 256)
   ↓
Encoder: 4× [ConvBlock → MaxPool]
   ↓
Bottleneck (with Dropout 0.3)
   ↓
Decoder: 4× [ConvTranspose + AttentionGate + ConvBlock]
   ↓
Conv2d 1×1 → logits (1, 256, 256)
   ↓
Threshold 0.5 → binary mask
   ↓
morphological close+dilate
   ↓
largest contour → fitEllipse (cx, cy, mn, mj, θ)
   ↓
minor axis endpoints → BPD_1, BPD_2
major axis endpoints → OFD_1, OFD_2
   ↓
Euclidean distance × pixel_spacing → mm
```

**Loss: Dice + Weighted BCE**
- `pos_weight = 140` (≈ 1/0.007, matching the 0.7% foreground ratio in HC18 masks)
- Without the pos_weight, the model collapses to predicting all-black

---

## Expected Performance (HC18-equivalent data)

| Metric | Part A | Part B |
|---|---|---|
| Overall MRE | ~1.5–2.5 mm | — |
| SDR@2mm | ~70–80% | — |
| SDR@4mm | ~90–95% | — |
| Dice Score | — | ~0.97–0.98 |
| BPD MAE | ~1.5–2.0 mm | ~2.0–3.0 mm |
| OFD MAE | ~1.5–2.0 mm | ~2.0–3.0 mm |
| HC MAE | ~2–4 mm | ~2–5 mm |

---

## Getting Pixel Spacing from DICOM

```python
import pydicom
ds = pydicom.dcmread("scan.dcm")
pixel_spacing_mm = float(ds.PixelSpacing[0])   # mm per pixel (row direction)
```

For HC18 PNG files, pixel spacing is provided in the dataset CSV as the `pixel_size` column (range: 0.052–0.326 mm/px).

---

## References

1. **Adaptive Wing Loss**: Wang et al., "Adaptive Wing Loss for Robust Face Alignment via Heatmap Regression", ICCV 2019
2. **Attention U-Net**: Oktay et al., "Attention U-Net: Learning Where to Look for the Pancreas", MIDL 2018
3. **U-Net**: Ronneberger et al., "U-Net: Convolutional Networks for Biomedical Image Segmentation", MICCAI 2015 — https://arxiv.org/pdf/1505.04597
4. **HC18 Dataset**: van den Heuvel et al., "Automated measurement of fetal head circumference", PLoS ONE 2018
5. **Multi-landmark CNNs**: Payer et al., "Regressing Heatmaps for Multiple Landmark Localization using CNNs"
