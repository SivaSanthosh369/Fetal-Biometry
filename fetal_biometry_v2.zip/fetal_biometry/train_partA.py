"""
train_partA.py
==============
Train the EfficientNet-B3 landmark detection model (Part A).

Usage:
    python train_partA.py
    python train_partA.py --epochs 80 --batch 8 --lr 5e-5
"""

import argparse
import os
import pandas as pd
import torch

import config as cfg
from src.shared.utils import filter_outliers
from src.shared.dataset import LandmarkDataset, build_dataloaders
from src.partA.model import LandmarkNet, AdaptiveWingLoss
from src.partA.trainer import train, evaluate, visualise, plot_history


def parse_args():
    p = argparse.ArgumentParser(description="Train Part A — Landmark Detection")
    p.add_argument("--data_dir",   default=cfg.DATA_DIR)
    p.add_argument("--annot_csv",  default=cfg.ANNOT_CSV)
    p.add_argument("--output_dir", default=cfg.OUTPUT_DIR_A)
    p.add_argument("--epochs",     type=int,   default=cfg.NUM_EPOCHS)
    p.add_argument("--batch",      type=int,   default=cfg.BATCH_SIZE)
    p.add_argument("--lr",         type=float, default=cfg.LR)
    p.add_argument("--eval_only",  action="store_true",
                   help="Skip training; only run evaluation on saved model")
    return p.parse_args()


def main():
    args = parse_args()
    cfg.NUM_EPOCHS  = args.epochs
    cfg.BATCH_SIZE  = args.batch
    cfg.LR          = args.lr
    cfg.OUTPUT_DIR_A = args.output_dir
    os.makedirs(cfg.OUTPUT_DIR_A, exist_ok=True)

    model_path = os.path.join(cfg.OUTPUT_DIR_A, "best_landmark_model.pth")

    # ── 1. Load & validate data ───────────────────────────────────────────
    print("\n[1/4] Loading dataset...")
    df = pd.read_csv(args.annot_csv)
    print(f"  Raw rows: {len(df)}")
    df = filter_outliers(df, cfg.MIN_LANDMARK_DIST_PX)
    print(f"  Clean rows: {len(df)}")

    # ── 2. Build dataloaders ──────────────────────────────────────────────
    print("\n[2/4] Building dataloaders...")
    train_dl, val_dl, train_df, val_df = build_dataloaders(
        LandmarkDataset, df, args.data_dir,
        batch_size=cfg.BATCH_SIZE
    )

    # ── 3. Model ──────────────────────────────────────────────────────────
    print("\n[3/4] Initialising model...")
    model = LandmarkNet(n_landmarks=cfg.N_LANDMARKS).to(cfg.DEVICE)
    print(f"  Trainable parameters: {model.count_parameters():,}")
    print(f"  Device: {cfg.DEVICE}")

    # ── 4. Train or evaluate ──────────────────────────────────────────────
    if not args.eval_only:
        print("\n[4/4] Training...")
        loss_fn = AdaptiveWingLoss()
        history = train(model, train_dl, val_dl, loss_fn, model_path)
        plot_history(history, os.path.join(cfg.OUTPUT_DIR_A, "train_curves.png"))
        print(f"\n  Training curves saved → {cfg.OUTPUT_DIR_A}/train_curves.png")

    # ── 5. Evaluate ───────────────────────────────────────────────────────
    if os.path.exists(model_path):
        print("\n[EVAL] Loading best model and evaluating...")
        model.load_state_dict(torch.load(model_path, map_location=cfg.DEVICE))
        errors = evaluate(model, val_dl)

        # Save per-sample errors
        import numpy as np
        err_path = os.path.join(cfg.OUTPUT_DIR_A, "val_errors.npy")
        np.save(err_path, errors)
        print(f"  Errors saved → {err_path}")

        # Visualise first 4 validation samples
        print("\n[VIZ] Generating sample predictions...")
        for i, row in val_df.head(4).iterrows():
            img_path = os.path.join(args.data_dir, row[cfg.IMG_COL])
            if not os.path.exists(img_path):
                continue
            result   = None
            try:
                from src.partA.trainer import predict
                result = predict(model, img_path)
            except Exception as e:
                print(f"  Skipped {row[cfg.IMG_COL]}: {e}")
                continue
            save = os.path.join(cfg.OUTPUT_DIR_A, f"pred_{row[cfg.IMG_COL]}")
            visualise(img_path, result, gt_row=row, save_path=save)
            print(f"  Saved → {save}")
    else:
        print(f"\n  No model found at {model_path}. Run without --eval_only first.")

    print("\n✓ Part A complete.")


if __name__ == "__main__":
    main()
