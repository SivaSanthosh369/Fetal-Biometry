"""
config.py — Central Configuration
All paths, hyperparameters, and constants in one place.
Edit this file before running any script.
"""

import os
import torch

# ─────────────────────────────────────────────────────────────────────────────
# PATHS  —  update these to match your local setup
# ─────────────────────────────────────────────────────────────────────────────
DATA_DIR   = "./data/training_set"         # folder containing HC ultrasound PNGs
MASK_DIR   = "./data/masks"                # folder containing *_Annotation.png masks
ANNOT_CSV  = "./data/ground_truth.csv"     # role_challenge_dataset_ground_truth.csv

OUTPUT_DIR_A = "./outputs/partA"           # Part A outputs
OUTPUT_DIR_B = "./outputs/partB"           # Part B outputs

# ─────────────────────────────────────────────────────────────────────────────
# IMAGE SETTINGS
# ─────────────────────────────────────────────────────────────────────────────
NATIVE_H, NATIVE_W = 540, 800             # HC18 native image size (px)
INPUT_SIZE         = 256                   # model input (square resize)
HEATMAP_SIZE       = 64                    # Part A: output heatmap resolution
SIGMA              = 3.0                   # Part A: GT Gaussian sigma
N_LANDMARKS        = 4                     # ofd_1, ofd_2, bpd_1, bpd_2
PIXEL_SPACING_MM   = 0.168                 # approximate mm/pixel for HC18

# ─────────────────────────────────────────────────────────────────────────────
# TRAINING HYPERPARAMETERS
# ─────────────────────────────────────────────────────────────────────────────
BATCH_SIZE  = 16
NUM_EPOCHS  = 60
LR          = 1e-4
WEIGHT_DECAY = 1e-5
VAL_FRAC    = 0.15
RANDOM_SEED = 42

# ─────────────────────────────────────────────────────────────────────────────
# HARDWARE
# ─────────────────────────────────────────────────────────────────────────────
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ─────────────────────────────────────────────────────────────────────────────
# COLUMN NAMES  (from role_challenge_dataset_ground_truth.csv)
# ─────────────────────────────────────────────────────────────────────────────
IMG_COL = "image_name"
LM_COLS = [
    ("ofd_1_x", "ofd_1_y"),   # OFD point 1  → heatmap channel 0
    ("ofd_2_x", "ofd_2_y"),   # OFD point 2  → heatmap channel 1
    ("bpd_1_x", "bpd_1_y"),   # BPD point 1  → heatmap channel 2
    ("bpd_2_x", "bpd_2_y"),   # BPD point 2  → heatmap channel 3
]
LM_NAMES = ["OFD_1", "OFD_2", "BPD_1", "BPD_2"]

# ─────────────────────────────────────────────────────────────────────────────
# PART B SPECIFIC
# ─────────────────────────────────────────────────────────────────────────────
POS_WEIGHT   = 140.0     # BCE positive class weight (1/0.007 foreground ratio)
SEG_BATCH    = 8         # segmentation uses more memory

# ─────────────────────────────────────────────────────────────────────────────
# OUTLIER FILTER
# ─────────────────────────────────────────────────────────────────────────────
MIN_LANDMARK_DIST_PX = 50   # rows with BPD or OFD dist < this are excluded

# ─────────────────────────────────────────────────────────────────────────────
# CREATE OUTPUT DIRS
# ─────────────────────────────────────────────────────────────────────────────
os.makedirs(OUTPUT_DIR_A, exist_ok=True)
os.makedirs(OUTPUT_DIR_B, exist_ok=True)
