"""
predict.py
==========
Run trained models on new images (no labels required).
Supports both Part A (landmark) and Part B (segmentation) models.

Usage:
    # Single image
    python predict.py --image path/to/image.png --model partA
    python predict.py --image path/to/image.png --model partB

    # Batch prediction on a folder
    python predict.py --image_dir ./test_images --model partA --output_dir ./predictions

    # With pixel spacing from DICOM
    python predict.py --image path/to/image.dcm --model partB --pixel_spacing 0.15
"""

import argparse
import os
import json
import cv2
import numpy as np
import pandas as pd
from pathlib import Path

import torch
import config as cfg


def load_model_partA(weights_path: str):
    from src.partA.model import LandmarkNet
    model = LandmarkNet(n_landmarks=cfg.N_LANDMARKS).to(cfg.DEVICE)
    model.load_state_dict(torch.load(weights_path, map_location=cfg.DEVICE))
    model.eval()
    print(f"  [Part A] Loaded model from {weights_path}")
    return model


def load_model_partB(weights_path: str):
    from src.partB.model import AttentionUNet
    model = AttentionUNet().to(cfg.DEVICE)
    model.load_state_dict(torch.load(weights_path, map_location=cfg.DEVICE))
    model.eval()
    print(f"  [Part B] Loaded model from {weights_path}")
    return model


def predict_single(model, img_path: str, part: str,
                   pixel_spacing: float = cfg.PIXEL_SPACING_MM) -> dict:
    if part == "partA":
        from src.partA.trainer import predict
    else:
        from src.partB.trainer import predict
    return predict(model, img_path, pixel_spacing)


def save_result(img_path, result, part, output_dir, pixel_spacing):
    fname = Path(img_path).stem

    # JSON results
    report = {
        "image":    img_path,
        "model":    part,
        "BPD_mm":   result.get("BPD_mm"),
        "OFD_mm":   result.get("OFD_mm"),
        "HC_mm":    result.get("HC_mm"),
        "landmarks": {k: list(v) for k, v in result.get("landmarks", {}).items()}
    }
    json_path = os.path.join(output_dir, f"{fname}_result.json")
    with open(json_path, "w") as f:
        json.dump(report, f, indent=2)

    # Visualisation
    png_path = os.path.join(output_dir, f"{fname}_prediction.png")
    if part == "partA":
        from src.partA.trainer import visualise
    else:
        from src.partB.trainer import visualise
    visualise(img_path, result, save_path=png_path)

    return report


def batch_predict(model, image_dir: str, part: str,
                  output_dir: str, pixel_spacing: float):
    exts   = {".png", ".jpg", ".jpeg", ".bmp", ".tiff"}
    images = [p for p in Path(image_dir).iterdir()
              if p.suffix.lower() in exts]
    print(f"  Found {len(images)} images in {image_dir}")

    results = []
    for img_path in sorted(images):
        try:
            res    = predict_single(model, str(img_path), part, pixel_spacing)
            if "error" in res:
                print(f"  [WARN] {img_path.name}: {res['error']}")
                continue
            report = save_result(str(img_path), res, part, output_dir, pixel_spacing)
            results.append(report)
            print(f"  ✓ {img_path.name}  BPD={report['BPD_mm']:.1f}mm  "
                  f"OFD={report['OFD_mm']:.1f}mm  HC={report['HC_mm']:.1f}mm")
        except Exception as e:
            print(f"  [ERROR] {img_path.name}: {e}")

    # Summary CSV
    if results:
        summary_df = pd.DataFrame([{
            "image":  r["image"],
            "BPD_mm": r["BPD_mm"],
            "OFD_mm": r["OFD_mm"],
            "HC_mm":  r["HC_mm"],
        } for r in results])
        csv_path = os.path.join(output_dir, "predictions_summary.csv")
        summary_df.to_csv(csv_path, index=False)
        print(f"\n  Summary CSV → {csv_path}")
        print(f"\n  Mean BPD: {summary_df.BPD_mm.mean():.1f} mm")
        print(f"  Mean OFD: {summary_df.OFD_mm.mean():.1f} mm")
        print(f"  Mean HC : {summary_df.HC_mm.mean():.1f}  mm")

    return results


def main():
    p = argparse.ArgumentParser(description="Fetal Biometry Prediction")
    p.add_argument("--model",          default="partA",
                   choices=["partA", "partB"],
                   help="Which model to use (partA or partB)")
    p.add_argument("--weights",        default=None,
                   help="Path to model weights .pth file "
                        "(defaults to outputs/partA/best_landmark_model.pth or "
                        "outputs/partB/best_seg_model.pth)")
    p.add_argument("--image",          default=None,
                   help="Path to a single image")
    p.add_argument("--image_dir",      default=None,
                   help="Path to a folder of images (batch mode)")
    p.add_argument("--output_dir",     default="./predictions")
    p.add_argument("--pixel_spacing",  type=float, default=cfg.PIXEL_SPACING_MM,
                   help="mm per pixel (from DICOM PixelSpacing tag)")
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # Resolve weights path
    if args.weights is None:
        if args.model == "partA":
            args.weights = os.path.join(cfg.OUTPUT_DIR_A, "best_landmark_model.pth")
        else:
            args.weights = os.path.join(cfg.OUTPUT_DIR_B, "best_seg_model.pth")

    if not os.path.exists(args.weights):
        print(f"ERROR: weights not found at {args.weights}")
        print("Train first with: python train_partA.py  or  python train_partB.py")
        return

    # Load model
    if args.model == "partA":
        model = load_model_partA(args.weights)
    else:
        model = load_model_partB(args.weights)

    # Single or batch
    if args.image:
        print(f"\nPredicting on: {args.image}")
        result = predict_single(model, args.image, args.model, args.pixel_spacing)
        if "error" in result:
            print(f"ERROR: {result['error']}")
        else:
            print(f"\n  BPD : {result.get('BPD_mm', result.get('BPD_px', 0)):.1f} "
                  f"{'mm' if 'BPD_mm' in result else 'px'}")
            print(f"  OFD : {result.get('OFD_mm', result.get('OFD_px', 0)):.1f} "
                  f"{'mm' if 'OFD_mm' in result else 'px'}")
            if "HC_mm" in result:
                print(f"  HC  : {result['HC_mm']:.1f} mm")
            save_result(args.image, result, args.model, args.output_dir, args.pixel_spacing)
            print(f"\n  Results saved → {args.output_dir}/")

    elif args.image_dir:
        print(f"\nBatch prediction on: {args.image_dir}")
        batch_predict(model, args.image_dir, args.model,
                      args.output_dir, args.pixel_spacing)
    else:
        print("Provide --image or --image_dir")


if __name__ == "__main__":
    main()
