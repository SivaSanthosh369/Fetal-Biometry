"""
src/partA/model.py
EfficientNet-B3 backbone + transposed-conv heatmap decoder for
direct landmark regression (Part A).
"""

import torch
import torch.nn as nn
import torchvision.models as models

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import config as cfg


class LandmarkNet(nn.Module):
    """
    Architecture:
        Encoder  : EfficientNet-B3 (ImageNet pretrained, 1-channel adapted)
                   → feature map (B, 1536, 8, 8) for 256×256 input
        Decoder  : 3 × ConvTranspose2d blocks → (B, N_LM, 64, 64) heatmaps
        Output   : Sigmoid-normalised heatmaps, one per landmark

    Heatmap channel order:
        0=OFD_1  1=OFD_2  2=BPD_1  3=BPD_2
    """

    def __init__(self, n_landmarks: int = cfg.N_LANDMARKS):
        super().__init__()

        # ── Encoder: EfficientNet-B3 features ────────────────────────────
        backbone = models.efficientnet_b3(
            weights=models.EfficientNet_B3_Weights.DEFAULT)

        # Patch first conv: 3 channels → 1 channel (grayscale ultrasound)
        old_conv = backbone.features[0][0]
        new_conv = nn.Conv2d(
            1, old_conv.out_channels,
            kernel_size=old_conv.kernel_size,
            stride=old_conv.stride,
            padding=old_conv.padding,
            bias=False
        )
        with torch.no_grad():
            new_conv.weight = nn.Parameter(
                old_conv.weight.mean(dim=1, keepdim=True))
        backbone.features[0][0] = new_conv

        self.encoder = backbone.features   # → (B, 1536, 8, 8)

        # ── Decoder: upsample 8→16→32→64, output N heatmaps ─────────────
        self.decoder = nn.Sequential(
            # 8×8 → 16×16
            nn.ConvTranspose2d(1536, 256, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),

            # 16×16 → 32×32
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128), nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128), nn.ReLU(inplace=True),

            # 32×32 → 64×64
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),  nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),  nn.ReLU(inplace=True),

            # 1×1 projection to landmark channels
            nn.Conv2d(64, n_landmarks, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, 1, 256, 256)
        Returns: (B, N_LM, 64, 64) heatmaps in [0, 1]
        """
        return self.decoder(self.encoder(x))

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ─────────────────────────────────────────────────────────────────────────────
# ADAPTIVE WING LOSS
# ─────────────────────────────────────────────────────────────────────────────

class AdaptiveWingLoss(nn.Module):
    """
    Adaptive Wing Loss (Wang et al., ICCV 2019).
    Specifically designed for heatmap regression in landmark detection.
    Penalises small errors near the Gaussian peak more aggressively than
    standard MSE while remaining robust to large errors far from the peak.

    Parameters from the original paper:
        omega=14, theta=0.5, epsilon=1, alpha=2.1
    """

    def __init__(self, omega: float = 14.0, theta: float = 0.5,
                 epsilon: float = 1.0, alpha: float = 2.1):
        super().__init__()
        self.omega   = omega
        self.theta   = theta
        self.epsilon = epsilon
        self.alpha   = alpha

    def forward(self, pred: torch.Tensor, gt: torch.Tensor) -> torch.Tensor:
        delta = (gt - pred).abs()

        A = (self.omega *
             (1.0 / (1.0 + (self.theta / self.epsilon) ** (self.alpha - gt))) *
             (self.alpha - gt) *
             (self.theta / self.epsilon) ** (self.alpha - gt - 1) /
             self.epsilon)

        C = self.theta * A - self.omega * torch.log(
            1.0 + (self.theta / self.epsilon) ** (self.alpha - gt))

        loss = torch.where(
            delta < self.theta,
            self.omega * torch.log(
                1.0 + (delta / self.epsilon) ** (self.alpha - gt)),
            A * delta - C
        )
        return loss.mean()
