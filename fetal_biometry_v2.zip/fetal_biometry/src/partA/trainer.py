"""
src/partA/trainer.py
Training loop, evaluation, and inference for Part A landmark detection.
"""

import os
import numpy as np
import torch
import torch.optim as optim
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import config as cfg
from src.shared.utils import heatmap_to_coord, load_image, compute_measurements
from src.shared.heatmap_viz import (
    save_all_heatmap_outputs, save_epoch_heatmaps, plot_batch_heatmaps
)


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def train(model, train_dl, val_dl, loss_fn, save_path: str):
    """
    Full training loop with cosine LR schedule and best-model checkpointing.

    Returns:
        history dict with keys 'train_loss', 'val_loss'
    """
    optimizer = optim.AdamW(model.parameters(),
                            lr=cfg.LR, weight_decay=cfg.WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=cfg.NUM_EPOCHS, eta_min=1e-6)

    best_val  = float("inf")
    history   = {"train_loss": [], "val_loss": []}

    print(f"\n{'─'*60}")
    print(f"  PART A — LANDMARK DETECTION TRAINING")
    print(f"  Device: {cfg.DEVICE}  |  Epochs: {cfg.NUM_EPOCHS}  |  Batch: {cfg.BATCH_SIZE}")
    print(f"{'─'*60}")

    for epoch in range(1, cfg.NUM_EPOCHS + 1):

        # ── Train ────────────────────────────────────────────────────────
        model.train()
        t_loss = 0.0
        for imgs, hms in train_dl:
            imgs, hms = imgs.to(cfg.DEVICE), hms.to(cfg.DEVICE)
            optimizer.zero_grad()
            loss = loss_fn(model(imgs), hms)
            loss.backward()
            optimizer.step()
            t_loss += loss.item() * imgs.size(0)
        t_loss /= len(train_dl.dataset)

        # ── Validate ─────────────────────────────────────────────────────
        model.eval()
        v_loss = 0.0
        with torch.no_grad():
            for imgs, hms in val_dl:
                imgs, hms = imgs.to(cfg.DEVICE), hms.to(cfg.DEVICE)
                v_loss += loss_fn(model(imgs), hms).item() * imgs.size(0)
        v_loss /= len(val_dl.dataset)

        scheduler.step()
        history["train_loss"].append(t_loss)
        history["val_loss"].append(v_loss)

        saved = ""
        if v_loss < best_val:
            best_val = v_loss
            torch.save(model.state_dict(), save_path)
            saved = "  ✓ saved"

        print(f"  Ep [{epoch:03d}/{cfg.NUM_EPOCHS}]  "
              f"Train: {t_loss:.5f}  Val: {v_loss:.5f}{saved}")

        # ── Heatmap snapshot every 10 epochs ─────────────────────────────
        if epoch % 10 == 0 or epoch == 1:
            model.eval()
            try:
                imgs_s, hms_s = next(iter(val_dl))
                with torch.no_grad():
                    pred_s = model(imgs_s[:1].to(cfg.DEVICE))[0].cpu().numpy()
                gt_s = hms_s[0].numpy()
                save_epoch_heatmaps(
                    epoch, pred_s, gt_s,
                    output_dir=os.path.dirname(save_path)
                )
            except Exception:
                pass  # never block training on viz errors

    print(f"\n  Best val loss: {best_val:.5f}")
    return history


# ─────────────────────────────────────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────────────────────────────────────

def evaluate(model, val_dl, pixel_spacing: float = cfg.PIXEL_SPACING_MM) -> np.ndarray:
    """
    Compute per-landmark Mean Radial Error (MRE) and
    Success Detection Rate (SDR) at 2 / 2.5 / 3 / 4 mm thresholds.

    Returns:
        errors: (N, 4) array of per-landmark errors in mm
    """
    model.eval()
    all_errors = []

    with torch.no_grad():
        for imgs, hms_gt in val_dl:
            preds  = model(imgs.to(cfg.DEVICE)).cpu().numpy()
            gts    = hms_gt.numpy()
            for b in range(imgs.size(0)):
                row_errs = []
                for k in range(cfg.N_LANDMARKS):
                    px, py = heatmap_to_coord(preds[b, k])
                    gx, gy = heatmap_to_coord(gts[b, k])
                    # Scale from heatmap space → original image space → mm
                    scale = (cfg.NATIVE_W / cfg.HEATMAP_SIZE) * pixel_spacing
                    err   = np.sqrt((px-gx)**2 + (py-gy)**2) * scale
                    row_errs.append(err)
                all_errors.append(row_errs)

    E = np.array(all_errors)   # (N, 4)

    print(f"\n{'='*56}")
    print(f"  LANDMARK DETECTION — EVALUATION RESULTS")
    print(f"  (pixel_spacing = {pixel_spacing:.4f} mm/px)")
    print(f"{'='*56}")
    for i, name in enumerate(cfg.LM_NAMES):
        print(f"  {name:<8}  MRE = {E[:,i].mean():.2f} ± {E[:,i].std():.2f} mm")
    print(f"  {'OVERALL':<8}  MRE = {E.mean():.2f} ± {E.std():.2f} mm")

    print(f"\n  Success Detection Rate (SDR) — all 4 landmarks:")
    for t in [2.0, 2.5, 3.0, 4.0]:
        sdr = (E < t).all(axis=1).mean() * 100
        print(f"    < {t:.1f} mm : {sdr:.1f}%")

    bpd_e = E[:, 2:].mean(axis=1)   # channels 2,3 = BPD_1, BPD_2
    ofd_e = E[:, :2].mean(axis=1)   # channels 0,1 = OFD_1, OFD_2
    print(f"\n  BPD measurement MAE : {bpd_e.mean():.2f} mm")
    print(f"  OFD measurement MAE : {ofd_e.mean():.2f} mm")
    print(f"{'='*56}\n")
    return E


# ─────────────────────────────────────────────────────────────────────────────
# INFERENCE
# ─────────────────────────────────────────────────────────────────────────────

def predict(model, img_path: str,
            pixel_spacing: float = cfg.PIXEL_SPACING_MM) -> dict:
    """
    Run full inference pipeline on a single ultrasound image.

    Returns:
        dict with:
            landmarks    : {OFD_1, OFD_2, BPD_1, BPD_2} → (x, y) in orig coords
            BPD_mm, OFD_mm, HC_mm
            heatmaps     : (4, 64, 64) numpy array
    """
    import cv2
    model.eval()

    img_orig = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img_orig is None:
        raise FileNotFoundError(img_path)
    oh, ow = img_orig.shape[:2]

    img = load_image(img_path, size=cfg.INPUT_SIZE)
    inp = torch.tensor(img).unsqueeze(0).unsqueeze(0).to(cfg.DEVICE)

    with torch.no_grad():
        hms = model(inp)[0].cpu().numpy()   # (4, 64, 64)

    landmarks = {}
    for k, name in enumerate(cfg.LM_NAMES):
        hx, hy = heatmap_to_coord(hms[k])
        # scale heatmap coords → original image pixel coords
        landmarks[name] = (hx * ow / cfg.HEATMAP_SIZE,
                           hy * oh / cfg.HEATMAP_SIZE)

    measurements = compute_measurements(
        {"BPD_1": landmarks["BPD_1"], "BPD_2": landmarks["BPD_2"],
         "OFD_1": landmarks["OFD_1"], "OFD_2": landmarks["OFD_2"]},
        pixel_spacing_mm=pixel_spacing
    )

    return {
        "landmarks":    landmarks,
        "heatmaps":     hms,
        "image_shape":  (oh, ow),
        **measurements
    }


# ─────────────────────────────────────────────────────────────────────────────
# VISUALISATION
# ─────────────────────────────────────────────────────────────────────────────

def visualise(img_path: str, result: dict,
              gt_row=None, save_path: str = None):
    """
    Full prediction visualisation using heatmap_viz module.
    Generates:
        *_heatmap_grid.png    — 4 individual landmark heatmaps
        *_heatmap_overlay.png — heatmaps blended onto ultrasound
        *_gt_vs_pred.png      — GT vs predicted (if gt_row given)
        *_heatmap_lines.png   — overlay + BPD/OFD measurement lines
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
    from src.shared.heatmap_viz import save_all_heatmap_outputs

    tag        = os.path.splitext(os.path.basename(img_path))[0]
    output_dir = os.path.dirname(save_path) if save_path else cfg.OUTPUT_DIR_A

    saved = save_all_heatmap_outputs(
        img_path        = img_path,
        pred_heatmaps   = result["heatmaps"],
        gt_heatmaps     = result.get("gt_heatmaps"),
        output_dir      = output_dir,
        tag             = tag,
        pixel_spacing_mm = cfg.PIXEL_SPACING_MM,
        gt_row          = gt_row,
    )
    for k, p in saved.items():
        print(f"  [{k}] → {p}")


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING CURVES
# ─────────────────────────────────────────────────────────────────────────────

def plot_history(history: dict, save_path: str):
    fig, ax = plt.subplots(figsize=(9, 4))
    fig.patch.set_facecolor("#0f1117"); ax.set_facecolor("#1a1d27")
    ax.plot(history["train_loss"], color="#FFD166", label="Train Loss")
    ax.plot(history["val_loss"],   color="#06D6A0", label="Val Loss")
    ax.set_xlabel("Epoch", color="#aaaaaa"); ax.set_ylabel("Loss", color="#aaaaaa")
    ax.set_title("Part A — Training Curves", color="white", fontweight="bold")
    ax.tick_params(colors="#aaaaaa")
    ax.legend(labelcolor="white", facecolor="#1a1d27", edgecolor="#2a2d3a")
    ax.grid(color="#2a2d3a", lw=0.5)
    for sp in ax.spines.values(): sp.set_edgecolor("#2a2d3a")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
