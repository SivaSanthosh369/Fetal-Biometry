"""
src/shared/utils.py
Shared utilities used by both Part A and Part B.
"""

import cv2
import numpy as np
from math import cos, sin, pi
from scipy.ndimage import gaussian_filter


# ─────────────────────────────────────────────────────────────────────────────
# IMAGE PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────

def apply_clahe(img: np.ndarray, clip: float = 2.0, grid: int = 8) -> np.ndarray:
    """
    Apply CLAHE (Contrast Limited Adaptive Histogram Equalisation) to a
    grayscale ultrasound image to enhance skull boundary visibility.
    """
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(grid, grid))
    return clahe.apply(img)


def load_image(path: str, size: int = 256) -> np.ndarray:
    """
    Load grayscale ultrasound PNG, apply CLAHE, resize to square, normalise.
    Returns float32 array in [0, 1], shape (H, W).
    """
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Image not found: {path}")
    img = apply_clahe(img)
    img = cv2.resize(img, (size, size))
    return img.astype(np.float32) / 255.0


def load_mask(path: str, size: int = 256) -> np.ndarray:
    """
    Load binary annotation mask PNG, resize (nearest-neighbour), binarise.
    Returns float32 array of {0, 1}, shape (H, W).
    """
    msk = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if msk is None:
        raise FileNotFoundError(f"Mask not found: {path}")
    msk = cv2.resize(msk, (size, size), interpolation=cv2.INTER_NEAREST)
    return (msk > 127).astype(np.float32)


def mask_name_from_image(image_name: str) -> str:
    """000_HC.png  →  000_HC_Annotation.png"""
    return image_name.replace(".png", "_Annotation.png")


# ─────────────────────────────────────────────────────────────────────────────
# HEATMAP UTILITIES  (Part A)
# ─────────────────────────────────────────────────────────────────────────────

def make_heatmap(x: float, y: float, H: int, W: int, sigma: float = 3.0) -> np.ndarray:
    """
    Generate a 2-D Gaussian heatmap centred at pixel (x, y).
    Returns normalised float32 array, shape (H, W), max = 1.
    """
    hm = np.zeros((H, W), dtype=np.float32)
    xi, yi = int(round(x)), int(round(y))
    if 0 <= xi < W and 0 <= yi < H:
        hm[yi, xi] = 1.0
    hm = gaussian_filter(hm, sigma=sigma)
    return hm / (hm.max() + 1e-8)


def heatmap_to_coord(hm: np.ndarray) -> tuple:
    """Return (x, y) of the argmax peak in a 2-D heatmap."""
    row, col = np.unravel_index(np.argmax(hm), hm.shape)
    return float(col), float(row)   # (x, y)


# ─────────────────────────────────────────────────────────────────────────────
# ELLIPSE UTILITIES  (Part B)
# ─────────────────────────────────────────────────────────────────────────────

def fit_ellipse_to_mask(binary_mask: np.ndarray):
    """
    Fit an ellipse to the largest contour in a binary mask.

    Args:
        binary_mask: uint8 array {0, 1} or {0, 255}

    Returns:
        (cx, cy, minor_axis, major_axis, angle_deg) or None if fitting fails.
    """
    m = (binary_mask > 0).astype(np.uint8)
    # Close small gaps in the outline, then dilate slightly
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE,  k)
    m = cv2.morphologyEx(m, cv2.MORPH_DILATE, k, iterations=1)

    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    if len(c) < 5:
        return None

    (cx, cy), (mn, mj), ang = cv2.fitEllipse(c)
    return cx, cy, float(mn), float(mj), float(ang)


def ellipse_to_landmarks(cx, cy, mn, mj, ang_deg,
                          model_h, model_w, orig_h, orig_w) -> dict:
    """
    Derive BPD and OFD landmark points from ellipse parameters and
    scale them back to original image pixel coordinates.

    Coordinate convention (OpenCV fitEllipse):
        ang_deg = rotation of MAJOR axis from horizontal
        minor axis (mn) → BPD endpoints
        major axis (mj) → OFD endpoints

    Returns:
        dict with keys BPD_1, BPD_2, OFD_1, OFD_2 each as (x, y) float tuple
        in original image pixel space.
    """
    theta = np.deg2rad(ang_deg)

    # BPD = minor axis endpoints (perpendicular to major)
    BPD_1 = (cx - (mn/2) * cos(theta + pi/2),  cy - (mn/2) * sin(theta + pi/2))
    BPD_2 = (cx + (mn/2) * cos(theta + pi/2),  cy + (mn/2) * sin(theta + pi/2))
    # OFD = major axis endpoints
    OFD_1 = (cx - (mj/2) * cos(theta),  cy - (mj/2) * sin(theta))
    OFD_2 = (cx + (mj/2) * cos(theta),  cy + (mj/2) * sin(theta))

    sx = orig_w / model_w
    sy = orig_h / model_h

    def scale(pt):
        return (pt[0] * sx, pt[1] * sy)

    return {
        "BPD_1": scale(BPD_1), "BPD_2": scale(BPD_2),
        "OFD_1": scale(OFD_1), "OFD_2": scale(OFD_2),
    }


# ─────────────────────────────────────────────────────────────────────────────
# BIOMETRY MEASUREMENTS
# ─────────────────────────────────────────────────────────────────────────────

def euclidean(p1: tuple, p2: tuple) -> float:
    return float(np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2))


def compute_measurements(landmarks: dict, pixel_spacing_mm: float = None) -> dict:
    """
    Compute BPD, OFD, and HC (head circumference approximation) from
    landmark points.

    Args:
        landmarks: dict with keys BPD_1, BPD_2, OFD_1, OFD_2
        pixel_spacing_mm: if provided, converts pixel distances to mm

    Returns:
        dict with BPD_px, OFD_px and (if spacing given) BPD_mm, OFD_mm, HC_mm
    """
    bpd_px = euclidean(landmarks["BPD_1"], landmarks["BPD_2"])
    ofd_px = euclidean(landmarks["OFD_1"], landmarks["OFD_2"])
    result = {"BPD_px": bpd_px, "OFD_px": ofd_px}
    if pixel_spacing_mm:
        result["BPD_mm"] = bpd_px * pixel_spacing_mm
        result["OFD_mm"] = ofd_px * pixel_spacing_mm
        result["HC_mm"]  = 1.62 * (result["BPD_mm"] + result["OFD_mm"]) / 2
    return result


# ─────────────────────────────────────────────────────────────────────────────
# DATA VALIDATION
# ─────────────────────────────────────────────────────────────────────────────

def filter_outliers(df, min_dist_px: int = 50):
    """
    Remove annotation rows where BPD or OFD chord length is suspiciously small
    (< min_dist_px pixels) — these are likely annotation errors.

    Known outlier images in HC18 dataset: 010_2HC, 040_HC, 079_HC,
    117_HC, 121_2HC, 129_HC, 142_HC, 144_2HC, 151_HC, 154_HC.
    """
    import numpy as np
    bpd = np.sqrt((df.bpd_2_x - df.bpd_1_x)**2 + (df.bpd_2_y - df.bpd_1_y)**2)
    ofd = np.sqrt((df.ofd_2_x - df.ofd_1_x)**2 + (df.ofd_2_y - df.ofd_1_y)**2)
    keep = (bpd >= min_dist_px) & (ofd >= min_dist_px)
    removed = int((~keep).sum())
    if removed > 0:
        print(f"[filter_outliers] Removed {removed} rows with dist < {min_dist_px}px")
    return df[keep].reset_index(drop=True)


# ─────────────────────────────────────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────────────────────────────────────

def mean_radial_error(pred_pts: list, gt_pts: list) -> float:
    """
    Mean Radial Error (MRE) in pixels.
    pred_pts / gt_pts: list of (x, y) tuples, one per landmark.
    """
    errs = [euclidean(p, g) for p, g in zip(pred_pts, gt_pts)]
    return float(np.mean(errs))


def success_detection_rate(errors: np.ndarray, threshold_mm: float) -> float:
    """
    SDR = fraction of samples where ALL landmark errors < threshold.
    errors: (N, K) array of per-landmark errors in mm.
    """
    return float((errors < threshold_mm).all(axis=1).mean() * 100)


def dice_score(pred: np.ndarray, target: np.ndarray, smooth: float = 1.0) -> float:
    """Dice coefficient for binary masks."""
    inter = float((pred * target).sum())
    return (2 * inter + smooth) / (pred.sum() + target.sum() + smooth)
