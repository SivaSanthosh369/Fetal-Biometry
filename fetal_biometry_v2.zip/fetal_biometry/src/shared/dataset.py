"""
src/shared/dataset.py
Base dataset class and augmentation utilities shared by Part A and B.
"""

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from pathlib import Path

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import config as cfg
from src.shared.utils import (
    load_image, load_mask, mask_name_from_image,
    make_heatmap, filter_outliers
)


# ─────────────────────────────────────────────────────────────────────────────
# AUGMENTATION
# ─────────────────────────────────────────────────────────────────────────────

class Augmenter:
    """
    Geometry-safe augmentation: flips and rotation applied identically
    to image and mask/heatmaps so spatial correspondence is preserved.
    """
    def __init__(self, hflip=0.5, vflip=0.3, rot_range=20, brightness=(0.8, 1.2)):
        self.hflip      = hflip
        self.vflip      = vflip
        self.rot_range  = rot_range
        self.brightness = brightness

    def __call__(self, img: np.ndarray, spatial: np.ndarray) -> tuple:
        """
        img:     (H, W) float32 image
        spatial: (H, W) or (C, H, W) mask / heatmap stack

        Returns augmented (img, spatial).
        """
        H, W = img.shape[:2]
        is_2d = spatial.ndim == 2

        # Horizontal flip
        if np.random.rand() < self.hflip:
            img     = np.fliplr(img).copy()
            spatial = (np.fliplr(spatial) if is_2d
                       else np.flip(spatial, axis=2)).copy()

        # Vertical flip
        if np.random.rand() < self.vflip:
            img     = np.flipud(img).copy()
            spatial = (np.flipud(spatial) if is_2d
                       else np.flip(spatial, axis=1)).copy()

        # Random rotation
        angle = np.random.uniform(-self.rot_range, self.rot_range)
        M = cv2.getRotationMatrix2D((W // 2, H // 2), angle, 1.0)
        img = cv2.warpAffine(img, M, (W, H))
        if is_2d:
            spatial = cv2.warpAffine(spatial, M, (W, H), flags=cv2.INTER_NEAREST)
        else:
            spatial = np.stack([
                cv2.warpAffine(spatial[c], M, (W, H), flags=cv2.INTER_NEAREST)
                for c in range(spatial.shape[0])
            ])

        # Brightness jitter (image only)
        alpha = np.random.uniform(*self.brightness)
        img   = np.clip(img * alpha, 0.0, 1.0)

        return img, spatial


# ─────────────────────────────────────────────────────────────────────────────
# PART A — LANDMARK DATASET
# ─────────────────────────────────────────────────────────────────────────────

class LandmarkDataset(Dataset):
    """
    Loads HC18 ultrasound images + generates 4-channel Gaussian heatmaps
    from the ground-truth CSV landmark annotations.

    Heatmap channel order:
        0 = OFD_1,  1 = OFD_2,  2 = BPD_1,  3 = BPD_2

    Returns:
        img_tensor : (1, INPUT_SIZE, INPUT_SIZE)   float32
        hm_tensor  : (4, HEATMAP_SIZE, HEATMAP_SIZE) float32
    """

    def __init__(self, df: pd.DataFrame, img_dir: str, augment: bool = False):
        self.df      = df.reset_index(drop=True)
        self.img_dir = img_dir
        self.aug     = Augmenter() if augment else None

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row  = self.df.iloc[idx]
        path = str(Path(self.img_dir) / row[cfg.IMG_COL])

        img = load_image(path, size=cfg.INPUT_SIZE)

        # Build ground-truth heatmaps scaled to HEATMAP_SIZE
        sx = cfg.HEATMAP_SIZE / cfg.NATIVE_W
        sy = cfg.HEATMAP_SIZE / cfg.NATIVE_H

        hms = []
        for xc, yc in cfg.LM_COLS:
            hx = float(row[xc]) * sx
            hy = float(row[yc]) * sy
            hms.append(make_heatmap(hx, hy,
                                    cfg.HEATMAP_SIZE, cfg.HEATMAP_SIZE,
                                    cfg.SIGMA))
        hms = np.stack(hms, axis=0)   # (4, HM, HM)

        if self.aug:
            # Resize heatmaps to img size for joint augmentation, then resize back
            hms_up = np.stack([
                cv2.resize(h, (cfg.INPUT_SIZE, cfg.INPUT_SIZE))
                for h in hms
            ])
            img, hms_up = self.aug(img, hms_up)
            hms = np.stack([
                cv2.resize(h, (cfg.HEATMAP_SIZE, cfg.HEATMAP_SIZE))
                for h in hms_up
            ])

        return (torch.tensor(img).unsqueeze(0),   # (1, 256, 256)
                torch.tensor(hms))                  # (4, 64, 64)


# ─────────────────────────────────────────────────────────────────────────────
# PART B — SEGMENTATION DATASET
# ─────────────────────────────────────────────────────────────────────────────

class SegmentationDataset(Dataset):
    """
    Loads HC18 ultrasound images + binary ellipse-outline annotation masks.

    Mask facts (from dataset analysis):
        - Strictly binary {0, 255}
        - Ellipse OUTLINES only (~0.7% white pixels)
        - 622 masks, all 540×800 px (14 minor variants)
        - 1:1 correspondence with ground-truth CSV

    Returns:
        img_tensor  : (1, INPUT_SIZE, INPUT_SIZE)  float32
        mask_tensor : (1, INPUT_SIZE, INPUT_SIZE)  float32  {0, 1}
    """

    def __init__(self, df: pd.DataFrame, img_dir: str,
                 mask_dir: str, augment: bool = False):
        self.df       = df.reset_index(drop=True)
        self.img_dir  = img_dir
        self.mask_dir = mask_dir
        self.aug      = Augmenter() if augment else None

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row   = self.df.iloc[idx]
        iname = row[cfg.IMG_COL]
        mname = mask_name_from_image(iname)

        img  = load_image(str(Path(self.img_dir)  / iname), size=cfg.INPUT_SIZE)
        mask = load_mask (str(Path(self.mask_dir) / mname), size=cfg.INPUT_SIZE)

        if self.aug:
            img, mask = self.aug(img, mask)

        return (torch.tensor(img).unsqueeze(0),    # (1, 256, 256)
                torch.tensor(mask).unsqueeze(0))    # (1, 256, 256)


# ─────────────────────────────────────────────────────────────────────────────
# DATA LOADING HELPER
# ─────────────────────────────────────────────────────────────────────────────

def build_dataloaders(dataset_class, df, *ds_args,
                      batch_size=16, num_workers=4, **ds_kwargs):
    """
    Split df into train/val and return two DataLoaders.
    """
    import torch
    from torch.utils.data import DataLoader
    np.random.seed(cfg.RANDOM_SEED)
    df = df.sample(frac=1, random_state=cfg.RANDOM_SEED).reset_index(drop=True)
    n_val    = max(1, int(len(df) * cfg.VAL_FRAC))
    val_df   = df.iloc[:n_val]
    train_df = df.iloc[n_val:]

    train_ds = dataset_class(train_df, *ds_args, augment=True,  **ds_kwargs)
    val_ds   = dataset_class(val_df,   *ds_args, augment=False, **ds_kwargs)

    train_dl = DataLoader(train_ds, batch_size=batch_size,
                          shuffle=True,  num_workers=num_workers, pin_memory=True)
    val_dl   = DataLoader(val_ds,   batch_size=batch_size,
                          shuffle=False, num_workers=num_workers, pin_memory=True)

    print(f"  Train: {len(train_ds)} samples  |  Val: {len(val_ds)} samples")
    return train_dl, val_dl, train_df, val_df
