"""
src/shared/heatmap_viz.py
=========================
Rich heatmap visualisation utilities for fetal biometry outputs.

Provides 5 distinct visualisation types:

1. plot_heatmap_grid        — 4-panel GT or predicted heatmaps per landmark
2. plot_heatmap_overlay     — heatmaps blended onto the ultrasound image
3. plot_gt_vs_pred          — side-by-side GT vs predicted heatmaps + error map
4. plot_batch_heatmaps      — multi-row grid for a validation batch
5. save_epoch_heatmaps      — called each epoch during training to track progress
6. plot_heatmap_with_lines  — heatmaps + BPD/OFD measurement lines overlaid

All functions write PNG files to disk and return the figure path.
"""

import os
import cv2
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.axes_grid1 import make_axes_locatable

# ─────────────────────────────────────────────────────────────────────────────
# COLOUR THEME
# ─────────────────────────────────────────────────────────────────────────────
BG   = "#0f1117"
PBG  = "#1a1d27"
TC   = "#e0e0e0"
GC   = "#2a2d3a"
AC   = "#aaaaaa"

# Per-landmark colours
LM_COLORS = {
    "OFD_1": "#06D6A0",   # teal
    "OFD_2": "#118AB2",   # blue
    "BPD_1": "#FFD166",   # yellow
    "BPD_2": "#EF476F",   # red-pink
}
LM_NAMES = ["OFD_1", "OFD_2", "BPD_1", "BPD_2"]
LM_LABELS = ["OFD Point 1", "OFD Point 2", "BPD Point 1", "BPD Point 2"]

# Custom per-landmark colormaps (black → landmark colour)
def _make_cmap(hex_color: str, name: str):
    r = int(hex_color[1:3], 16) / 255
    g = int(hex_color[3:5], 16) / 255
    b = int(hex_color[5:7], 16) / 255
    return LinearSegmentedColormap.from_list(
        name, [(0, 0, 0), (r, g, b)], N=256)

LM_CMAPS = {k: _make_cmap(v, k) for k, v in LM_COLORS.items()}


def _style(ax, title="", fontsize=10):
    ax.set_facecolor(PBG)
    if title:
        ax.set_title(title, color=TC, fontsize=fontsize, fontweight="bold", pad=6)
    ax.tick_params(colors=AC, labelsize=7)
    for sp in ax.spines.values():
        sp.set_edgecolor(GC)


def _hm_to_coord(hm: np.ndarray):
    """Return (x, y) of argmax peak in a 2-D heatmap."""
    r, c = np.unravel_index(np.argmax(hm), hm.shape)
    return float(c), float(r)


# ─────────────────────────────────────────────────────────────────────────────
# 1. HEATMAP GRID — 4 panels, one per landmark
# ─────────────────────────────────────────────────────────────────────────────

def plot_heatmap_grid(heatmaps: np.ndarray,
                      title: str = "Predicted Heatmaps",
                      save_path: str = None) -> str:
    """
    Draw 4 individual heatmaps (one per landmark) in a 1×4 row.

    Args:
        heatmaps  : (4, H, W) float32 array, values in [0, 1]
        title     : figure title
        save_path : output PNG path (auto-generated if None)

    Returns:
        save_path string
    """
    fig, axes = plt.subplots(1, 4, figsize=(18, 4))
    fig.patch.set_facecolor(BG)
    fig.suptitle(title, color=TC, fontsize=13, fontweight="bold", y=1.01)

    for i, (ax, name, label) in enumerate(zip(axes, LM_NAMES, LM_LABELS)):
        hm = heatmaps[i]
        px, py = _hm_to_coord(hm)

        im = ax.imshow(hm, cmap=LM_CMAPS[name], vmin=0, vmax=1,
                       interpolation="bilinear")
        ax.scatter(px, py, s=120, c="white", marker="+", linewidths=2, zorder=5)
        ax.text(px + 1, py - 1, f"({px:.0f},{py:.0f})",
                color="white", fontsize=7, zorder=6)

        # Colorbar
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.05)
        cb  = fig.colorbar(im, cax=cax)
        cb.ax.tick_params(colors=AC, labelsize=7)
        cb.set_label("Confidence", color=AC, fontsize=7)

        _style(ax, f"{label}\n(peak={hm.max():.3f})")
        ax.set_xlabel("x (heatmap px)", color=AC, fontsize=7)
        ax.set_ylabel("y (heatmap px)", color=AC, fontsize=7)

    plt.tight_layout()
    if save_path is None:
        save_path = "/tmp/heatmap_grid.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# 2. HEATMAP OVERLAY — heatmaps blended onto original ultrasound
# ─────────────────────────────────────────────────────────────────────────────

def plot_heatmap_overlay(img_path: str,
                         heatmaps: np.ndarray,
                         alpha: float = 0.55,
                         save_path: str = None) -> str:
    """
    Blend all 4 heatmaps as coloured overlays onto the grayscale ultrasound.
    Each landmark channel is coloured with its own colour, then composited.

    Args:
        img_path  : path to the original ultrasound PNG
        heatmaps  : (4, H, W) in [0,1]
        alpha     : heatmap opacity (0=invisible, 1=opaque)
        save_path : output PNG path

    Returns:
        save_path
    """
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    oh, ow = img.shape
    img_rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB).astype(np.float32) / 255.

    # Build composite colour heatmap by adding per-landmark coloured maps
    composite = np.zeros((oh, ow, 3), dtype=np.float32)
    colors_rgb = {
        "OFD_1": np.array([0.024, 0.839, 0.627]),   # #06D6A0
        "OFD_2": np.array([0.067, 0.541, 0.698]),   # #118AB2
        "BPD_1": np.array([1.000, 0.820, 0.400]),   # #FFD166
        "BPD_2": np.array([0.937, 0.278, 0.435]),   # #EF476F
    }

    peak_coords = {}
    for i, name in enumerate(LM_NAMES):
        hm_up = cv2.resize(heatmaps[i], (ow, oh))  # upsample to original size
        hm_up = hm_up[:, :, None]                   # (H, W, 1)
        composite += hm_up * colors_rgb[name]
        px, py = _hm_to_coord(heatmaps[i])
        peak_coords[name] = (px * ow / heatmaps.shape[2],
                             py * oh / heatmaps.shape[1])

    composite = np.clip(composite, 0, 1)
    blended   = (1 - alpha) * img_rgb + alpha * composite
    blended   = np.clip(blended, 0, 1)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.patch.set_facecolor(BG)
    fig.suptitle("Heatmap Overlay on Ultrasound", color=TC,
                 fontsize=13, fontweight="bold")

    # Panel 1: original
    axes[0].imshow(img, cmap="gray"); _style(axes[0], "Original Image")
    axes[0].axis("off")

    # Panel 2: heatmap composite only
    axes[1].imshow(composite); _style(axes[1], "Heatmap Composite (all landmarks)")
    axes[1].axis("off")

    # Panel 3: blended with landmark markers
    axes[2].imshow(blended)
    for name, (px, py) in peak_coords.items():
        clr_hex = LM_COLORS[name]
        axes[2].scatter(px, py, s=150, c=clr_hex,
                        edgecolors="white", linewidths=1.5, zorder=5)
        axes[2].text(px + 8, py - 8, name, color=clr_hex,
                     fontsize=9, fontweight="bold", zorder=6)
    # BPD and OFD lines
    lm = peak_coords
    axes[2].plot([lm["BPD_1"][0], lm["BPD_2"][0]],
                 [lm["BPD_1"][1], lm["BPD_2"][1]],
                 color=LM_COLORS["BPD_1"], lw=2, ls="--", label="BPD", alpha=0.9)
    axes[2].plot([lm["OFD_1"][0], lm["OFD_2"][0]],
                 [lm["OFD_1"][1], lm["OFD_2"][1]],
                 color=LM_COLORS["OFD_1"], lw=2, ls="--", label="OFD", alpha=0.9)
    axes[2].legend(loc="lower right", fontsize=9, labelcolor="white",
                   facecolor=PBG, edgecolor=GC)
    _style(axes[2], f"Blended Overlay  (α={alpha})")
    axes[2].axis("off")

    # Legend strip
    from matplotlib.patches import Patch
    patches = [Patch(facecolor=LM_COLORS[n], label=LM_LABELS[i])
               for i, n in enumerate(LM_NAMES)]
    fig.legend(handles=patches, loc="lower center", ncol=4, fontsize=9,
               labelcolor="white", facecolor=PBG, edgecolor=GC)

    plt.tight_layout(rect=[0, 0.06, 1, 1])
    if save_path is None:
        save_path = "/tmp/heatmap_overlay.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# 3. GT vs PREDICTED — side-by-side with error map
# ─────────────────────────────────────────────────────────────────────────────

def plot_gt_vs_pred(gt_heatmaps: np.ndarray,
                    pred_heatmaps: np.ndarray,
                    img_path: str = None,
                    save_path: str = None) -> str:
    """
    3-row × 4-col grid:
        Row 0: Ground-truth heatmaps
        Row 1: Predicted heatmaps
        Row 2: Absolute error maps  |pred - gt|

    Args:
        gt_heatmaps   : (4, H, W) ground truth
        pred_heatmaps : (4, H, W) model predictions
        img_path      : optional — if given, image shown in header
        save_path     : output PNG path

    Returns:
        save_path
    """
    n_cols  = 4
    n_rows  = 3 if img_path is None else 4
    fig_h   = 3.5 * n_rows
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(4.2 * n_cols, fig_h))
    fig.patch.set_facecolor(BG)
    fig.suptitle("Ground Truth vs Predicted Heatmaps",
                 color=TC, fontsize=14, fontweight="bold", y=1.01)

    row_labels = ["Ground Truth", "Predicted", "Error  |GT − Pred|"]
    row_cmaps  = [None, None, "hot"]   # None = per-landmark cmap

    if img_path is not None:
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        for c in range(n_cols):
            axes[0, c].imshow(img, cmap="gray")
            axes[0, c].axis("off")
            if c == 0:
                _style(axes[0, c], "Input Image")
        row_offset = 1
        data_rows  = [(gt_heatmaps, "Ground Truth"),
                      (pred_heatmaps, "Predicted"),
                      (np.abs(gt_heatmaps - pred_heatmaps), "Error  |GT − Pred|")]
        cmaps_used = [None, None, "hot"]
    else:
        row_offset = 0
        data_rows  = [(gt_heatmaps, "Ground Truth"),
                      (pred_heatmaps, "Predicted"),
                      (np.abs(gt_heatmaps - pred_heatmaps), "Error  |GT − Pred|")]
        cmaps_used = [None, None, "hot"]

    for r_idx, (hms, row_label) in enumerate(data_rows):
        ax_row = r_idx + row_offset
        for c, name in enumerate(LM_NAMES):
            ax  = axes[ax_row, c]
            hm  = hms[c]
            cmap = cmaps_used[r_idx] if cmaps_used[r_idx] else LM_CMAPS[name]
            im  = ax.imshow(hm, cmap=cmap, vmin=0, vmax=1,
                             interpolation="bilinear")
            px, py = _hm_to_coord(hm)
            ax.scatter(px, py, s=80, c="white", marker="+", linewidths=1.5, zorder=5)

            col_title = f"{LM_LABELS[c]}" if ax_row == 0 + row_offset else ""
            _style(ax, col_title, fontsize=9)

            if c == 0:
                ax.set_ylabel(row_label, color=TC, fontsize=9, fontweight="bold")
            ax.set_xticks([]); ax.set_yticks([])

            # Tiny colorbar on last column
            if c == 3:
                divider = make_axes_locatable(ax)
                cax     = divider.append_axes("right", size="6%", pad=0.05)
                cb      = fig.colorbar(im, cax=cax)
                cb.ax.tick_params(colors=AC, labelsize=6)

            # Per-channel MSE annotation on error row
            if r_idx == 2:
                mse = float((hm ** 2).mean())
                ax.set_xlabel(f"MSE={mse:.5f}", color=AC, fontsize=7)

    plt.tight_layout()
    if save_path is None:
        save_path = "/tmp/gt_vs_pred.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# 4. BATCH HEATMAP GRID — N samples × 4 landmarks
# ─────────────────────────────────────────────────────────────────────────────

def plot_batch_heatmaps(heatmaps_batch: np.ndarray,
                        image_names: list = None,
                        n_samples: int = 6,
                        title: str = "Validation Batch — Predicted Heatmaps",
                        save_path: str = None) -> str:
    """
    Visualise heatmaps for multiple images in a grid:
        Rows = samples, Columns = 4 landmarks

    Args:
        heatmaps_batch : (N, 4, H, W) numpy array
        image_names    : optional list of N image names for row labels
        n_samples      : max rows to show
        save_path      : output PNG path

    Returns:
        save_path
    """
    N = min(n_samples, len(heatmaps_batch))
    fig, axes = plt.subplots(N, 4, figsize=(4.2 * 4, 3.2 * N))
    fig.patch.set_facecolor(BG)
    fig.suptitle(title, color=TC, fontsize=13, fontweight="bold", y=1.01)

    if N == 1:
        axes = axes[np.newaxis, :]   # keep 2-D indexing

    for r in range(N):
        for c, name in enumerate(LM_NAMES):
            ax = axes[r, c]
            hm = heatmaps_batch[r, c]
            ax.imshow(hm, cmap=LM_CMAPS[name], vmin=0, vmax=1,
                      interpolation="bilinear")
            px, py = _hm_to_coord(hm)
            ax.scatter(px, py, s=60, c="white", marker="+", linewidths=1.5, zorder=5)
            _style(ax, LM_LABELS[c] if r == 0 else "", fontsize=8)
            ax.set_xticks([]); ax.set_yticks([])
            if c == 0 and image_names:
                ax.set_ylabel(image_names[r], color=AC, fontsize=7, rotation=0,
                              labelpad=55, va="center")

    plt.tight_layout()
    if save_path is None:
        save_path = "/tmp/batch_heatmaps.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# 5. EPOCH HEATMAP SNAPSHOT — called during training to track learning
# ─────────────────────────────────────────────────────────────────────────────

def save_epoch_heatmaps(epoch: int,
                         pred_heatmaps: np.ndarray,
                         gt_heatmaps: np.ndarray,
                         output_dir: str,
                         img_path: str = None) -> str:
    """
    Save a GT-vs-predicted heatmap snapshot for a single sample at a
    given training epoch. Lets you visually track model improvement over time.

    Output: {output_dir}/heatmaps/epoch_{epoch:03d}.png

    Call this every N epochs inside the training loop.
    """
    hm_dir = os.path.join(output_dir, "heatmaps")
    os.makedirs(hm_dir, exist_ok=True)
    save_path = os.path.join(hm_dir, f"epoch_{epoch:03d}.png")
    plot_gt_vs_pred(gt_heatmaps, pred_heatmaps,
                    img_path=img_path, save_path=save_path)
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# 6. HEATMAP + MEASUREMENT LINES — combined in one figure
# ─────────────────────────────────────────────────────────────────────────────

def plot_heatmap_with_lines(img_path: str,
                             heatmaps: np.ndarray,
                             pixel_spacing_mm: float = None,
                             gt_row=None,
                             save_path: str = None) -> str:
    """
    Full prediction visualisation:
        Panel 1: Ultrasound image
        Panel 2: All 4 heatmaps (2×2 grid, coloured)
        Panel 3: Image + heatmap overlay + BPD/OFD measurement lines
        Panel 4 (if gt_row): GT comparison

    Args:
        img_path         : path to ultrasound PNG
        heatmaps         : (4, H, W) predicted heatmaps
        pixel_spacing_mm : if given, compute mm distances
        gt_row           : pandas row from GT CSV for comparison
        save_path        : output PNG path

    Returns:
        save_path
    """
    img  = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    oh, ow = img.shape

    # Compute peak coords in original image space
    Hm, Wm = heatmaps.shape[1], heatmaps.shape[2]
    peaks  = {}
    for i, name in enumerate(LM_NAMES):
        px, py = _hm_to_coord(heatmaps[i])
        peaks[name] = (px * ow / Wm, py * oh / Hm)

    def dist(a, b):
        return np.sqrt((a[0]-b[0])**2+(a[1]-b[1])**2)

    bpd_px = dist(peaks["BPD_1"], peaks["BPD_2"])
    ofd_px = dist(peaks["OFD_1"], peaks["OFD_2"])
    if pixel_spacing_mm:
        bpd_s = f"BPD: {bpd_px*pixel_spacing_mm:.1f} mm"
        ofd_s = f"OFD: {ofd_px*pixel_spacing_mm:.1f} mm"
        hc_s  = f"HC: {1.62*(bpd_px+ofd_px)/2*pixel_spacing_mm:.1f} mm"
    else:
        bpd_s = f"BPD: {bpd_px:.0f} px"
        ofd_s = f"OFD: {ofd_px:.0f} px"
        hc_s  = ""

    n_panels = 4 if gt_row is not None else 3
    fig, axes = plt.subplots(1, n_panels, figsize=(5.5*n_panels, 5.5))
    fig.patch.set_facecolor(BG)
    fig.suptitle(f"Landmark Detection Output    {bpd_s}   {ofd_s}   {hc_s}",
                 color=TC, fontsize=12, fontweight="bold")

    # ── Panel 1: Original image ───────────────────────────────────────────
    axes[0].imshow(img, cmap="gray")
    _style(axes[0], "Input Ultrasound"); axes[0].axis("off")

    # ── Panel 2: 2×2 coloured heatmaps ───────────────────────────────────
    hm_grid_top = np.concatenate([
        _colorise_hm(heatmaps[0], LM_COLORS["OFD_1"]),
        _colorise_hm(heatmaps[1], LM_COLORS["OFD_2"]),
    ], axis=1)
    hm_grid_bot = np.concatenate([
        _colorise_hm(heatmaps[2], LM_COLORS["BPD_1"]),
        _colorise_hm(heatmaps[3], LM_COLORS["BPD_2"]),
    ], axis=1)
    hm_grid = np.concatenate([hm_grid_top, hm_grid_bot], axis=0)
    axes[1].imshow(hm_grid)
    # Labels for sub-quadrants
    Hg, Wg = hm_grid.shape[:2]
    for txt, pos in [("OFD_1", (Wg*0.25, Hg*0.07)),
                     ("OFD_2", (Wg*0.75, Hg*0.07)),
                     ("BPD_1", (Wg*0.25, Hg*0.57)),
                     ("BPD_2", (Wg*0.75, Hg*0.57))]:
        axes[1].text(pos[0], pos[1], txt, color=LM_COLORS[txt],
                     fontsize=9, fontweight="bold", ha="center",
                     bbox=dict(facecolor=BG, alpha=0.6, pad=1, edgecolor="none"))
    _style(axes[1], "Predicted Heatmaps\n(OFD top | BPD bottom)")
    axes[1].axis("off")

    # ── Panel 3: Overlay + measurement lines ─────────────────────────────
    overlay = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB).astype(np.float32) / 255.
    colors_rgb = {
        "OFD_1": np.array([0.024, 0.839, 0.627]),
        "OFD_2": np.array([0.067, 0.541, 0.698]),
        "BPD_1": np.array([1.000, 0.820, 0.400]),
        "BPD_2": np.array([0.937, 0.278, 0.435]),
    }
    composite = np.zeros((oh, ow, 3), dtype=np.float32)
    for i, name in enumerate(LM_NAMES):
        hm_up = cv2.resize(heatmaps[i], (ow, oh))[:, :, None]
        composite += hm_up * colors_rgb[name]
    blended = np.clip(0.55*overlay + 0.45*np.clip(composite, 0, 1), 0, 1)

    axes[2].imshow(blended)
    axes[2].plot([peaks["BPD_1"][0], peaks["BPD_2"][0]],
                 [peaks["BPD_1"][1], peaks["BPD_2"][1]],
                 color=LM_COLORS["BPD_1"], lw=2.5, label="BPD")
    axes[2].plot([peaks["OFD_1"][0], peaks["OFD_2"][0]],
                 [peaks["OFD_1"][1], peaks["OFD_2"][1]],
                 color=LM_COLORS["OFD_1"], lw=2.5, label="OFD")
    for name, (px, py) in peaks.items():
        axes[2].scatter(px, py, s=100, c=LM_COLORS[name],
                        edgecolors="white", linewidths=1, zorder=5)
        axes[2].text(px+7, py-7, name, color=LM_COLORS[name],
                     fontsize=8, fontweight="bold", zorder=6)
    axes[2].legend(loc="lower right", fontsize=9, labelcolor="white",
                   facecolor=PBG, edgecolor=GC)
    _style(axes[2], f"Heatmap Overlay + Measurements")
    axes[2].axis("off")

    # ── Panel 4 (optional): GT comparison ───────────────────────────────
    if gt_row is not None:
        ax4 = axes[3]; ax4.imshow(cv2.cvtColor(img, cv2.COLOR_GRAY2RGB))
        ax4.plot([gt_row.bpd_1_x, gt_row.bpd_2_x],
                 [gt_row.bpd_1_y, gt_row.bpd_2_y],
                 color="#FF6B6B", lw=2.5, ls="--", label="GT BPD")
        ax4.plot([gt_row.ofd_1_x, gt_row.ofd_2_x],
                 [gt_row.ofd_1_y, gt_row.ofd_2_y],
                 color="#4ECDC4", lw=2.5, ls="--", label="GT OFD")
        ax4.plot([peaks["BPD_1"][0], peaks["BPD_2"][0]],
                 [peaks["BPD_1"][1], peaks["BPD_2"][1]],
                 color=LM_COLORS["BPD_1"], lw=2, label="Pred BPD")
        ax4.plot([peaks["OFD_1"][0], peaks["OFD_2"][0]],
                 [peaks["OFD_1"][1], peaks["OFD_2"][1]],
                 color=LM_COLORS["OFD_1"], lw=2, label="Pred OFD")
        # Error circles at each GT point
        for gx, gy, name in [
            (gt_row.bpd_1_x, gt_row.bpd_1_y, "BPD_1"),
            (gt_row.bpd_2_x, gt_row.bpd_2_y, "BPD_2"),
            (gt_row.ofd_1_x, gt_row.ofd_1_y, "OFD_1"),
            (gt_row.ofd_2_x, gt_row.ofd_2_y, "OFD_2"),
        ]:
            px, py = peaks[name]
            err_px = np.sqrt((px-gx)**2+(py-gy)**2)
            ax4.annotate("", xy=(px, py), xytext=(gx, gy),
                         arrowprops=dict(arrowstyle="->",
                                         color="white", lw=1.2))
            mid = ((px+gx)/2+5, (py+gy)/2)
            ax4.text(mid[0], mid[1], f"{err_px:.0f}px",
                     color="white", fontsize=7, alpha=0.85)
        ax4.legend(loc="lower right", fontsize=8, labelcolor="white",
                   facecolor=PBG, edgecolor=GC)
        _style(ax4, "GT vs Prediction\n(arrows = error vectors)")
        ax4.axis("off")

    plt.tight_layout()
    if save_path is None:
        save_path = "/tmp/heatmap_lines.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    return save_path


# ─────────────────────────────────────────────────────────────────────────────
# HELPER — colourise a single heatmap as RGB
# ─────────────────────────────────────────────────────────────────────────────

def _colorise_hm(hm: np.ndarray, hex_color: str) -> np.ndarray:
    """Return (H, W, 3) float32 RGB array for a heatmap channel."""
    r = int(hex_color[1:3], 16) / 255
    g = int(hex_color[3:5], 16) / 255
    b = int(hex_color[5:7], 16) / 255
    rgb = np.stack([hm * r, hm * g, hm * b], axis=-1)
    return rgb.astype(np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE — generate all heatmap outputs in one call
# ─────────────────────────────────────────────────────────────────────────────

def save_all_heatmap_outputs(img_path: str,
                              pred_heatmaps: np.ndarray,
                              gt_heatmaps: np.ndarray = None,
                              output_dir: str = "./outputs",
                              tag: str = "sample",
                              pixel_spacing_mm: float = None,
                              gt_row=None) -> dict:
    """
    Generate and save all heatmap visualisation types for one image.

    Args:
        img_path        : path to ultrasound PNG
        pred_heatmaps   : (4, H, W) model output
        gt_heatmaps     : (4, H, W) ground truth heatmaps (optional)
        output_dir      : folder to save outputs
        tag             : filename prefix (e.g. image stem)
        pixel_spacing_mm: for mm conversion in labels
        gt_row          : pandas row for GT landmark comparison

    Returns:
        dict of {output_type: saved_path}
    """
    os.makedirs(output_dir, exist_ok=True)
    saved = {}

    # 1. Heatmap grid (predicted)
    saved["heatmap_grid"] = plot_heatmap_grid(
        pred_heatmaps,
        title=f"Predicted Heatmaps — {tag}",
        save_path=os.path.join(output_dir, f"{tag}_heatmap_grid.png")
    )

    # 2. Overlay
    saved["heatmap_overlay"] = plot_heatmap_overlay(
        img_path, pred_heatmaps,
        save_path=os.path.join(output_dir, f"{tag}_heatmap_overlay.png")
    )

    # 3. GT vs Pred (if GT available)
    if gt_heatmaps is not None:
        saved["gt_vs_pred"] = plot_gt_vs_pred(
            gt_heatmaps, pred_heatmaps, img_path=img_path,
            save_path=os.path.join(output_dir, f"{tag}_gt_vs_pred.png")
        )

    # 4. Lines + heatmap combined
    saved["heatmap_lines"] = plot_heatmap_with_lines(
        img_path, pred_heatmaps,
        pixel_spacing_mm=pixel_spacing_mm,
        gt_row=gt_row,
        save_path=os.path.join(output_dir, f"{tag}_heatmap_lines.png")
    )

    return saved
