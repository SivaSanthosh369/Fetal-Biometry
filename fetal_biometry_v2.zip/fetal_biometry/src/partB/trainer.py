"""
src/partB/trainer.py
Training loop, evaluation, and inference for Part B segmentation approach.
"""

import os
import json
import numpy as np
import cv2
import torch
import torch.optim as optim
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import config as cfg
from src.shared.utils import (
    load_image, fit_ellipse_to_mask, ellipse_to_landmarks,
    compute_measurements, dice_score
)


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def train(model, train_dl, val_dl, loss_fn, save_path: str):
    """
    Training loop with ReduceLROnPlateau scheduler and Dice-based
    best-model checkpointing.
    """
    optimizer = optim.AdamW(model.parameters(),
                            lr=cfg.LR, weight_decay=cfg.WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=cfg.NUM_EPOCHS, eta_min=1e-6)

    best_dice = 0.0
    history   = {"train_loss": [], "val_loss": [], "val_dice": []}

    print(f"\n{'─'*60}")
    print(f"  PART B — SEGMENTATION TRAINING")
    print(f"  Device: {cfg.DEVICE}  |  Epochs: {cfg.NUM_EPOCHS}  |  Batch: {cfg.SEG_BATCH}")
    print(f"{'─'*60}")

    for epoch in range(1, cfg.NUM_EPOCHS + 1):

        # ── Train ────────────────────────────────────────────────────────
        model.train()
        t_loss = 0.0
        for imgs, msks in train_dl:
            imgs, msks = imgs.to(cfg.DEVICE), msks.to(cfg.DEVICE)
            optimizer.zero_grad()
            loss = loss_fn(model(imgs), msks)
            loss.backward()
            optimizer.step()
            t_loss += loss.item() * imgs.size(0)
        t_loss /= len(train_dl.dataset)

        # ── Validate ─────────────────────────────────────────────────────
        model.eval()
        v_loss = v_dice = 0.0
        with torch.no_grad():
            for imgs, msks in val_dl:
                imgs, msks = imgs.to(cfg.DEVICE), msks.to(cfg.DEVICE)
                out  = model(imgs)
                v_loss += loss_fn(out, msks).item() * imgs.size(0)
                pred  = (torch.sigmoid(out) > 0.5).float()
                inter = (pred * msks).sum((2, 3))
                d = ((2*inter+1) / (pred.sum((2,3)) + msks.sum((2,3)) + 1)).mean().item()
                v_dice += d * imgs.size(0)

        v_loss /= len(val_dl.dataset)
        v_dice /= len(val_dl.dataset)
        scheduler.step()

        history["train_loss"].append(t_loss)
        history["val_loss"].append(v_loss)
        history["val_dice"].append(v_dice)

        saved = ""
        if v_dice > best_dice:
            best_dice = v_dice
            torch.save(model.state_dict(), save_path)
            saved = "  ✓ saved"

        print(f"  Ep [{epoch:03d}/{cfg.NUM_EPOCHS}]  "
              f"Loss: {t_loss:.4f}/{v_loss:.4f}  "
              f"Dice: {v_dice:.4f}{saved}")

    print(f"\n  Best Val Dice: {best_dice:.4f}")
    return history


# ─────────────────────────────────────────────────────────────────────────────
# INFERENCE — Full Pipeline
# ─────────────────────────────────────────────────────────────────────────────

def predict(model, img_path: str,
            pixel_spacing: float = cfg.PIXEL_SPACING_MM) -> dict:
    """
    End-to-end pipeline:
        image → U-Net → predicted outline mask
               → fitEllipse → ellipse params
               → landmark points (BPD_1, BPD_2, OFD_1, OFD_2)
               → BPD_mm, OFD_mm, HC_mm

    Returns dict with all intermediate and final results.
    """
    model.eval()

    img_orig = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img_orig is None:
        raise FileNotFoundError(img_path)
    oh, ow = img_orig.shape[:2]

    img = load_image(img_path, size=cfg.INPUT_SIZE)
    inp = torch.tensor(img).unsqueeze(0).unsqueeze(0).to(cfg.DEVICE)

    with torch.no_grad():
        logit = model(inp)
    pred_mask = (torch.sigmoid(logit)[0, 0].cpu().numpy() > 0.5).astype(np.uint8)

    ell = fit_ellipse_to_mask(pred_mask)
    if ell is None:
        return {"error": "Ellipse fitting failed", "mask": pred_mask}

    cx, cy, mn, mj, ang = ell
    landmarks = ellipse_to_landmarks(
        cx, cy, mn, mj, ang,
        model_h=cfg.INPUT_SIZE, model_w=cfg.INPUT_SIZE,
        orig_h=oh, orig_w=ow
    )
    measurements = compute_measurements(landmarks, pixel_spacing_mm=pixel_spacing)

    return {
        "mask":         pred_mask,
        "ellipse":      ell,           # (cx, cy, minor, major, angle_deg)
        "landmarks":    landmarks,     # {BPD_1, BPD_2, OFD_1, OFD_2}
        "image_shape":  (oh, ow),
        **measurements
    }


# ─────────────────────────────────────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────────────────────────────────────

def evaluate(model, val_df, img_dir: str, mask_dir: str,
             pixel_spacing: float = cfg.PIXEL_SPACING_MM) -> dict:
    """
    Compute segmentation Dice and biometry MAE (BPD, OFD) across
    the validation set, comparing against CSV ground truth.
    """
    from src.shared.utils import load_mask, mask_name_from_image
    from pathlib import Path

    model.eval()
    dice_scores, bpd_errs, ofd_errs = [], [], []

    for _, row in val_df.iterrows():
        img_path = str(Path(img_dir)  / row[cfg.IMG_COL])
        msk_path = str(Path(mask_dir) / mask_name_from_image(row[cfg.IMG_COL]))

        # Ground-truth mask for Dice
        try:
            gt_msk = load_mask(msk_path, size=cfg.INPUT_SIZE)
        except FileNotFoundError:
            continue

        result = predict(model, img_path, pixel_spacing)
        if "error" in result:
            continue

        # Dice
        d = dice_score(result["mask"].astype(np.float32), gt_msk)
        dice_scores.append(d)

        # BPD / OFD error vs CSV ground truth
        lm = result["landmarks"]
        from src.shared.utils import euclidean
        pred_bpd = euclidean(lm["BPD_1"], lm["BPD_2"]) * pixel_spacing
        pred_ofd = euclidean(lm["OFD_1"], lm["OFD_2"]) * pixel_spacing
        gt_bpd = np.sqrt((row.bpd_2_x-row.bpd_1_x)**2 +
                         (row.bpd_2_y-row.bpd_1_y)**2) * pixel_spacing
        gt_ofd = np.sqrt((row.ofd_2_x-row.ofd_1_x)**2 +
                         (row.ofd_2_y-row.ofd_1_y)**2) * pixel_spacing
        bpd_errs.append(abs(pred_bpd - gt_bpd))
        ofd_errs.append(abs(pred_ofd - gt_ofd))

    D = np.array(dice_scores)
    B = np.array(bpd_errs)
    O = np.array(ofd_errs)

    print(f"\n{'='*52}")
    print(f"  SEGMENTATION + BIOMETRY — EVALUATION")
    print(f"{'='*52}")
    print(f"  Dice Score    : {D.mean():.4f} ± {D.std():.4f}")
    print(f"  BPD MAE       : {B.mean():.2f} ± {B.std():.2f} mm")
    print(f"  OFD MAE       : {O.mean():.2f} ± {O.std():.2f} mm")
    print(f"  HC  MAE (est) : {((B+O)/2*1.62).mean():.2f} mm")
    print(f"{'='*52}\n")

    return {"dice": D, "bpd_err": B, "ofd_err": O}


# ─────────────────────────────────────────────────────────────────────────────
# VISUALISATION
# ─────────────────────────────────────────────────────────────────────────────

def visualise(img_path: str, result: dict,
              gt_row=None, save_path: str = None):
    """Draw mask, ellipse, BPD/OFD lines on the ultrasound image."""
    img  = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    oh, ow = img.shape[:2]
    lm   = result["landmarks"]
    cx, cy, mn, mj, ang = result["ellipse"]

    n_panels = 3 if gt_row is None else 4
    fig, axes = plt.subplots(1, n_panels, figsize=(5*n_panels, 5))
    fig.patch.set_facecolor("#0f1117")

    # Panel 1 — original
    axes[0].imshow(img, cmap="gray")
    axes[0].set_title("Original Ultrasound", color="white", fontsize=10); axes[0].axis("off")

    # Panel 2 — predicted mask
    mask_disp = cv2.resize(result["mask"].astype(np.uint8)*255, (ow, oh))
    axes[1].imshow(mask_disp, cmap="gray")
    axes[1].set_title("Predicted Outline Mask", color="white", fontsize=10); axes[1].axis("off")

    # Panel 3 — overlay with ellipse and measurement lines
    overlay = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    ax = axes[2]; ax.imshow(overlay)

    from matplotlib.patches import Ellipse as MEll
    # Draw ellipse in original image space
    sx = ow / cfg.INPUT_SIZE; sy = oh / cfg.INPUT_SIZE
    ell_patch = MEll((cx*sx, cy*sy), mj*sx, mn*sy, angle=ang,
                     edgecolor="white", facecolor="none", lw=1.5, ls="--", alpha=0.7)
    ax.add_patch(ell_patch)

    ax.plot([lm["BPD_1"][0], lm["BPD_2"][0]], [lm["BPD_1"][1], lm["BPD_2"][1]],
            color="#FFD166", lw=2.5, label="BPD")
    ax.plot([lm["OFD_1"][0], lm["OFD_2"][0]], [lm["OFD_1"][1], lm["OFD_2"][1]],
            color="#06D6A0", lw=2.5, label="OFD")
    for name, (x, y) in lm.items():
        clr = "#FFD166" if "BPD" in name else "#06D6A0"
        ax.scatter(x, y, s=70, c=clr, zorder=5)
        ax.text(x+5, y-5, name, color=clr, fontsize=9, fontweight="bold")

    bpd_s = f"{result.get('BPD_mm', result.get('BPD_px',0)):.1f}{'mm' if 'BPD_mm' in result else 'px'}"
    ofd_s = f"{result.get('OFD_mm', result.get('OFD_px',0)):.1f}{'mm' if 'OFD_mm' in result else 'px'}"
    hc_s  = f"  HC: {result['HC_mm']:.1f}mm" if "HC_mm" in result else ""
    ax.set_title(f"BPD: {bpd_s}  OFD: {ofd_s}{hc_s}", color="white", fontsize=10)
    ax.legend(loc="lower right", fontsize=8, labelcolor="white",
              facecolor="#1a1d27", edgecolor="#2a2d3a")
    ax.axis("off")

    # Panel 4 (optional) — GT vs Prediction
    if gt_row is not None:
        ax4 = axes[3]; ax4.imshow(overlay)
        ax4.plot([gt_row.bpd_1_x, gt_row.bpd_2_x],
                 [gt_row.bpd_1_y, gt_row.bpd_2_y],
                 color="#FF6B6B", lw=2.5, ls="--", label="GT BPD")
        ax4.plot([gt_row.ofd_1_x, gt_row.ofd_2_x],
                 [gt_row.ofd_1_y, gt_row.ofd_2_y],
                 color="#4ECDC4", lw=2.5, ls="--", label="GT OFD")
        ax4.plot([lm["BPD_1"][0], lm["BPD_2"][0]],
                 [lm["BPD_1"][1], lm["BPD_2"][1]],
                 color="#FFD166", lw=2, label="Pred BPD")
        ax4.plot([lm["OFD_1"][0], lm["OFD_2"][0]],
                 [lm["OFD_1"][1], lm["OFD_2"][1]],
                 color="#06D6A0", lw=2, label="Pred OFD")
        ax4.set_title("GT vs Prediction", color="white", fontsize=10)
        ax4.legend(loc="lower right", fontsize=7, labelcolor="white",
                   facecolor="#1a1d27", edgecolor="#2a2d3a")
        ax4.axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
    plt.close()


def plot_history(history: dict, save_path: str):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    fig.patch.set_facecolor("#0f1117")
    for ax in (ax1, ax2):
        ax.set_facecolor("#1a1d27")
        ax.tick_params(colors="#aaaaaa")
        ax.grid(color="#2a2d3a", lw=0.5)
        for sp in ax.spines.values(): sp.set_edgecolor("#2a2d3a")

    ax1.plot(history["train_loss"], color="#FFD166", label="Train")
    ax1.plot(history["val_loss"],   color="#06D6A0", label="Val")
    ax1.set_title("Loss", color="white", fontweight="bold")
    ax1.set_xlabel("Epoch", color="#aaaaaa"); ax1.legend(labelcolor="white", facecolor="#1a1d27", edgecolor="#2a2d3a")

    ax2.plot(history["val_dice"], color="#EF476F", label="Val Dice")
    ax2.set_title("Dice Score", color="white", fontweight="bold")
    ax2.set_xlabel("Epoch", color="#aaaaaa"); ax2.legend(labelcolor="white", facecolor="#1a1d27", edgecolor="#2a2d3a")

    fig.suptitle("Part B — Training Curves", color="white", fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
