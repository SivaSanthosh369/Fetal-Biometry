"""
src/partB/model.py
Attention U-Net for fetal skull ellipse-outline segmentation (Part B).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
import config as cfg


# ─────────────────────────────────────────────────────────────────────────────
# BUILDING BLOCKS
# ─────────────────────────────────────────────────────────────────────────────

class ConvBlock(nn.Module):
    """Double Conv → BN → ReLU block (standard U-Net building block)."""
    def __init__(self, in_ch: int, out_ch: int, dropout: float = 0.0):
        super().__init__()
        layers = [
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
        ]
        if dropout > 0:
            layers.insert(3, nn.Dropout2d(dropout))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class AttentionGate(nn.Module):
    """
    Additive soft attention gate (Oktay et al., MIDL 2018).
    Learns to focus on skull-boundary features while suppressing
    the speckle noise typical in ultrasound images.

    g  = gating signal from decoder (coarser scale)
    x  = skip connection from encoder (finer scale)
    """
    def __init__(self, F_g: int, F_l: int, F_int: int):
        super().__init__()
        self.W_g   = nn.Sequential(
            nn.Conv2d(F_g,  F_int, kernel_size=1, bias=False),
            nn.BatchNorm2d(F_int))
        self.W_x   = nn.Sequential(
            nn.Conv2d(F_l,  F_int, kernel_size=1, bias=False),
            nn.BatchNorm2d(F_int))
        self.psi   = nn.Sequential(
            nn.Conv2d(F_int, 1, kernel_size=1, bias=False),
            nn.BatchNorm2d(1),
            nn.Sigmoid())

    def forward(self, g: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
        att = self.psi(F.relu(self.W_g(g) + self.W_x(x), inplace=True))
        return x * att


# ─────────────────────────────────────────────────────────────────────────────
# ATTENTION U-NET
# ─────────────────────────────────────────────────────────────────────────────

class AttentionUNet(nn.Module):
    """
    4-level Attention U-Net for HC18 cranium outline segmentation.

    Input : (B, 1, 256, 256)
    Output: (B, 1, 256, 256) — logits (use sigmoid for probabilities)

    Feature map sizes (with INPUT_SIZE=256):
        enc1:  (B, 64,  256, 256)
        enc2:  (B, 128, 128, 128)
        enc3:  (B, 256,  64,  64)
        enc4:  (B, 512,  32,  32)
        bttnk: (B, 1024, 16,  16)
        dec4:  (B, 512,  32,  32)
        dec3:  (B, 256,  64,  64)
        dec2:  (B, 128, 128, 128)
        dec1:  (B, 64,  256, 256)
        out:   (B, 1,   256, 256)

    Why Attention U-Net for this task:
        The mask is only ~0.7% of pixels (outline, not filled region).
        Attention gates suppress the large black background and
        focus decoder capacity on the thin skull boundary, leading
        to sharper, more accurate outline predictions.
    """

    def __init__(self, in_ch: int = 1, out_ch: int = 1,
                 filters: tuple = (64, 128, 256, 512)):
        super().__init__()
        f = filters

        # ── Encoder ───────────────────────────────────────────────────────
        self.enc1 = ConvBlock(in_ch, f[0])
        self.enc2 = ConvBlock(f[0],  f[1])
        self.enc3 = ConvBlock(f[1],  f[2])
        self.enc4 = ConvBlock(f[2],  f[3], dropout=0.3)
        self.pool = nn.MaxPool2d(2)

        # ── Bottleneck ───────────────────────────────────────────────────
        self.bottleneck = ConvBlock(f[3], f[3]*2, dropout=0.3)

        # ── Decoder + Attention Gates ─────────────────────────────────────
        self.up4  = nn.ConvTranspose2d(f[3]*2, f[3], kernel_size=2, stride=2)
        self.ag4  = AttentionGate(F_g=f[3],   F_l=f[3],   F_int=f[3]//2)
        self.dec4 = ConvBlock(f[3]*2, f[3])

        self.up3  = nn.ConvTranspose2d(f[3], f[2], kernel_size=2, stride=2)
        self.ag3  = AttentionGate(F_g=f[2],   F_l=f[2],   F_int=f[2]//2)
        self.dec3 = ConvBlock(f[2]*2, f[2])

        self.up2  = nn.ConvTranspose2d(f[2], f[1], kernel_size=2, stride=2)
        self.ag2  = AttentionGate(F_g=f[1],   F_l=f[1],   F_int=f[1]//2)
        self.dec2 = ConvBlock(f[1]*2, f[1])

        self.up1  = nn.ConvTranspose2d(f[1], f[0], kernel_size=2, stride=2)
        self.ag1  = AttentionGate(F_g=f[0],   F_l=f[0],   F_int=f[0]//2)
        self.dec1 = ConvBlock(f[0]*2, f[0])

        # ── Output head ──────────────────────────────────────────────────
        self.out_conv = nn.Conv2d(f[0], out_ch, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Encoder
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))

        # Bottleneck
        b  = self.bottleneck(self.pool(e4))

        # Decoder with skip + attention
        u4 = self.up4(b)
        d4 = self.dec4(torch.cat([self.ag4(u4, e4), u4], dim=1))

        u3 = self.up3(d4)
        d3 = self.dec3(torch.cat([self.ag3(u3, e3), u3], dim=1))

        u2 = self.up2(d3)
        d2 = self.dec2(torch.cat([self.ag2(u2, e2), u2], dim=1))

        u1 = self.up1(d2)
        d1 = self.dec1(torch.cat([self.ag1(u1, e1), u1], dim=1))

        return self.out_conv(d1)

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ─────────────────────────────────────────────────────────────────────────────
# WEIGHTED DICE + BCE LOSS
# ─────────────────────────────────────────────────────────────────────────────

class DiceBCELoss(nn.Module):
    """
    Combined Dice + Binary Cross-Entropy loss for highly imbalanced
    binary segmentation.

    Dataset imbalance: only ~0.7% of pixels are foreground (skull outline).
    pos_weight = 1/0.007 ≈ 140 counteracts the BCE collapsing to all-zero.
    Dice term additionally penalises missing the thin outline structure.

    Args:
        pos_weight: BCE positive class weight (default 140.0 for HC18)
        smooth:     Dice smoothing constant
    """

    def __init__(self, pos_weight: float = cfg.POS_WEIGHT, smooth: float = 1.0):
        super().__init__()
        self.register_buffer("pw", torch.tensor([pos_weight]))
        self.smooth = smooth

    def forward(self, logits: torch.Tensor,
                targets: torch.Tensor) -> torch.Tensor:
        # Weighted BCE
        bce  = F.binary_cross_entropy_with_logits(
            logits, targets,
            pos_weight=self.pw.to(logits.device))

        # Dice
        pred  = torch.sigmoid(logits)
        inter = (pred * targets).sum(dim=(2, 3))
        dice  = 1.0 - (2.0 * inter + self.smooth) / (
            pred.sum(dim=(2, 3)) + targets.sum(dim=(2, 3)) + self.smooth)

        return bce + dice.mean()
