"""
explore_dataset.py
==================
Dataset Explorer — run this BEFORE training to:
  1. Validate annotations and masks
  2. Detect and flag outliers
  3. Print summary statistics
  4. Generate visualisation dashboards

Usage:
    python explore_dataset.py
    python explore_dataset.py --annot_csv ./data/ground_truth.csv
"""

import argparse
import os
import json
import cv2
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

import config as cfg
from src.shared.utils import filter_outliers, mask_name_from_image


BG   = "#0f1117"
PBG  = "#1a1d27"
TC   = "#e0e0e0"
GC   = "#2a2d3a"
AC   = "#aaaaaa"
CYEL = "#FFD166"
CGRN = "#06D6A0"
CRED = "#EF476F"
CBLU = "#118AB2"


def sax(ax, title):
    ax.set_facecolor(PBG)
    ax.set_title(title, color=TC, fontsize=10, fontweight="bold", pad=7)
    ax.tick_params(colors=AC, labelsize=8)
    for sp in ax.spines.values(): sp.set_edgecolor(GC)
    ax.grid(color=GC, lw=0.5, alpha=0.7)


# ─────────────────────────────────────────────────────────────────────────────

def analyse_annotations(df):
    """Compute derived columns, detect outliers, print statistics."""
    df = df.copy()
    df["BPD_dist"] = np.sqrt((df.bpd_2_x-df.bpd_1_x)**2 + (df.bpd_2_y-df.bpd_1_y)**2)
    df["OFD_dist"] = np.sqrt((df.ofd_2_x-df.ofd_1_x)**2 + (df.ofd_2_y-df.ofd_1_y)**2)
    df["ratio"]    = df["OFD_dist"] / df["BPD_dist"]
    df["BPD_mid_x"] = (df.bpd_1_x + df.bpd_2_x) / 2
    df["BPD_mid_y"] = (df.bpd_1_y + df.bpd_2_y) / 2
    df["OFD_mid_x"] = (df.ofd_1_x + df.ofd_2_x) / 2
    df["OFD_mid_y"] = (df.ofd_1_y + df.ofd_2_y) / 2

    outliers = df[(df.BPD_dist < 50) | (df.OFD_dist < 50)]
    clean    = df[(df.BPD_dist >= 50) & (df.OFD_dist >= 50)]

    print(f"\n{'='*55}")
    print(f"  ANNOTATION STATISTICS")
    print(f"{'='*55}")
    print(f"  Total rows     : {len(df)}")
    print(f"  Outliers (<50px): {len(outliers)}")
    print(f"  Clean rows     : {len(clean)}")
    print(f"\n  BPD distance   : mean={clean.BPD_dist.mean():.1f}  std={clean.BPD_dist.std():.1f}  px")
    print(f"  OFD distance   : mean={clean.OFD_dist.mean():.1f}  std={clean.OFD_dist.std():.1f}  px")
    print(f"  OFD/BPD ratio  : median={clean.ratio.median():.3f}  (clinical ~0.77)")
    print(f"  Image size     : max_x={max(df[['bpd_1_x','bpd_2_x','ofd_1_x','ofd_2_x']].max())}")
    print(f"                   max_y={max(df[['bpd_1_y','bpd_2_y','ofd_1_y','ofd_2_y']].max())}")

    if len(outliers):
        print(f"\n  Outlier images (BPD or OFD < 50px):")
        for _, r in outliers.iterrows():
            print(f"    {r.image_name}  BPD={r.BPD_dist:.0f}px  OFD={r.OFD_dist:.0f}px")
    print(f"{'='*55}\n")
    return df, clean, outliers


def analyse_masks(mask_dir: str):
    """Inspect mask PNGs — sizes, pixel values, contour stats."""
    masks = sorted(Path(mask_dir).glob("*.png"))
    if not masks:
        print(f"  [WARN] No masks found in {mask_dir}")
        return {}

    areas, sizes = [], []
    for m in masks:
        img = cv2.imread(str(m), cv2.IMREAD_GRAYSCALE)
        if img is None: continue
        sizes.append(img.shape)
        areas.append((img > 127).sum())
    areas = np.array(areas)

    from collections import Counter
    size_ct = Counter(sizes)
    print(f"\n  MASK STATISTICS ({len(masks)} files)")
    print(f"  Most common size: {size_ct.most_common(1)[0]}")
    print(f"  Size variants   : {len(size_ct)}")
    print(f"  White px/image  : mean={areas.mean():.0f}  std={areas.std():.0f}")
    print(f"  Foreground %    : {areas.mean()/(540*800)*100:.2f}%")
    return {"areas": areas, "n_masks": len(masks)}


def plot_annotation_dashboard(df_full, df_clean, output_path):
    """9-panel annotation analysis figure."""
    fig = plt.figure(figsize=(18, 14))
    fig.patch.set_facecolor(BG)
    gs  = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

    # 1. BPD histogram
    ax = fig.add_subplot(gs[0, 0])
    ax.hist(df_clean.BPD_dist, bins=40, color=CYEL, alpha=0.85, edgecolor="none")
    ax.axvline(df_clean.BPD_dist.mean(), color="white", lw=1.5, ls="--",
               label=f"μ={df_clean.BPD_dist.mean():.0f}px")
    ax.set_xlabel("Pixels", color=AC, fontsize=8)
    ax.legend(fontsize=8, labelcolor="white", facecolor=PBG, edgecolor=GC)
    sax(ax, "BPD Distance Distribution")

    # 2. OFD histogram
    ax = fig.add_subplot(gs[0, 1])
    ax.hist(df_clean.OFD_dist, bins=40, color=CGRN, alpha=0.85, edgecolor="none")
    ax.axvline(df_clean.OFD_dist.mean(), color="white", lw=1.5, ls="--",
               label=f"μ={df_clean.OFD_dist.mean():.0f}px")
    ax.set_xlabel("Pixels", color=AC, fontsize=8)
    ax.legend(fontsize=8, labelcolor="white", facecolor=PBG, edgecolor=GC)
    sax(ax, "OFD Distance Distribution")

    # 3. BPD vs OFD scatter
    ax = fig.add_subplot(gs[0, 2])
    sc = ax.scatter(df_clean.BPD_dist, df_clean.OFD_dist, alpha=0.3, s=10,
                    c=df_clean.ratio, cmap="plasma")
    cb = fig.colorbar(sc, ax=ax); cb.ax.tick_params(colors=AC, labelsize=7)
    cb.set_label("OFD/BPD ratio", color=AC, fontsize=7)
    m, b = np.polyfit(df_clean.BPD_dist, df_clean.OFD_dist, 1)
    xl = np.linspace(df_clean.BPD_dist.min(), df_clean.BPD_dist.max(), 100)
    ax.plot(xl, m*xl+b, color="white", lw=1.5, ls="--", alpha=0.7)
    corr = df_clean.BPD_dist.corr(df_clean.OFD_dist)
    ax.set_xlabel("BPD (px)", color=AC, fontsize=8)
    ax.set_ylabel("OFD (px)", color=AC, fontsize=8)
    ax.set_facecolor(PBG); ax.tick_params(colors=AC, labelsize=8)
    for sp in ax.spines.values(): sp.set_edgecolor(GC)
    ax.grid(color=GC, lw=0.5, alpha=0.7)
    ax.set_title(f"BPD vs OFD  (r={corr:.3f})", color=TC, fontsize=10, fontweight="bold", pad=7)

    # 4. BPD midpoint density
    ax = fig.add_subplot(gs[1, 0])
    h, xe, ye = np.histogram2d(df_clean.BPD_mid_x, df_clean.BPD_mid_y, bins=40)
    ax.imshow(h.T, origin="lower", extent=[xe[0], xe[-1], ye[0], ye[-1]],
              cmap="YlOrRd", aspect="auto")
    ax.set_xlabel("X", color=AC, fontsize=8); ax.set_ylabel("Y", color=AC, fontsize=8)
    sax(ax, "BPD Midpoint Density")

    # 5. OFD midpoint density
    ax = fig.add_subplot(gs[1, 1])
    h, xe, ye = np.histogram2d(df_clean.OFD_mid_x, df_clean.OFD_mid_y, bins=40)
    ax.imshow(h.T, origin="lower", extent=[xe[0], xe[-1], ye[0], ye[-1]],
              cmap="GnBu", aspect="auto")
    ax.set_xlabel("X", color=AC, fontsize=8); ax.set_ylabel("Y", color=AC, fontsize=8)
    sax(ax, "OFD Midpoint Density")

    # 6. OFD/BPD ratio
    ax = fig.add_subplot(gs[1, 2])
    ax.hist(df_clean.ratio, bins=40, color=CRED, alpha=0.85, edgecolor="none")
    ax.axvline(df_clean.ratio.median(), color="white", lw=1.5, ls="--",
               label=f"median={df_clean.ratio.median():.3f}")
    ax.axvline(0.77, color=CYEL, lw=1.2, ls=":", label="clinical ~0.77")
    ax.set_xlabel("OFD/BPD", color=AC, fontsize=8)
    ax.legend(fontsize=7.5, labelcolor="white", facecolor=PBG, edgecolor=GC)
    sax(ax, "OFD/BPD Ratio")

    # 7. BPD point cloud
    ax = fig.add_subplot(gs[2, 0])
    ax.scatter(df_clean.bpd_1_x, df_clean.bpd_1_y, alpha=0.2, s=6, c=CYEL, label="BPD_1")
    ax.scatter(df_clean.bpd_2_x, df_clean.bpd_2_y, alpha=0.2, s=6, c=CYEL, marker="x", label="BPD_2")
    ax.invert_yaxis()
    ax.legend(fontsize=8, labelcolor="white", facecolor=PBG, edgecolor=GC)
    ax.set_xlabel("X", color=AC, fontsize=8); ax.set_ylabel("Y", color=AC, fontsize=8)
    sax(ax, "BPD Landmark Positions")

    # 8. OFD point cloud
    ax = fig.add_subplot(gs[2, 1])
    ax.scatter(df_clean.ofd_1_x, df_clean.ofd_1_y, alpha=0.2, s=6, c=CGRN, label="OFD_1")
    ax.scatter(df_clean.ofd_2_x, df_clean.ofd_2_y, alpha=0.2, s=6, c=CGRN, marker="x", label="OFD_2")
    ax.invert_yaxis()
    ax.legend(fontsize=8, labelcolor="white", facecolor=PBG, edgecolor=GC)
    ax.set_xlabel("X", color=AC, fontsize=8); ax.set_ylabel("Y", color=AC, fontsize=8)
    sax(ax, "OFD Landmark Positions")

    # 9. Angle polar plot
    ax = fig.add_subplot(gs[2, 2], polar=True)
    ax.set_facecolor(PBG)
    bpd_ang = np.arctan2(df_clean.bpd_2_y-df_clean.bpd_1_y, df_clean.bpd_2_x-df_clean.bpd_1_x)
    ofd_ang = np.arctan2(df_clean.ofd_2_y-df_clean.ofd_1_y, df_clean.ofd_2_x-df_clean.ofd_1_x)
    bins_r  = np.linspace(-np.pi, np.pi, 37)
    bh, _   = np.histogram(bpd_ang, bins=bins_r)
    oh, _   = np.histogram(ofd_ang, bins=bins_r)
    ctrs    = (bins_r[:-1]+bins_r[1:])/2
    w       = bins_r[1]-bins_r[0]
    ax.bar(ctrs, bh, width=w, alpha=0.6, color=CYEL, label="BPD")
    ax.bar(ctrs, oh, width=w, alpha=0.6, color=CGRN, label="OFD")
    ax.set_title("Measurement Angles", color=TC, fontsize=10, fontweight="bold", pad=14)
    ax.tick_params(colors=AC, labelsize=7)
    ax.legend(fontsize=8, labelcolor="white", facecolor=PBG, edgecolor=GC, loc="lower right")

    fig.suptitle(f"Ground Truth Annotation Analysis  (n={len(df_clean)} clean, {len(df_full)} total)",
                 color="white", fontsize=14, fontweight="bold", y=0.99)
    plt.savefig(output_path, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Annotation dashboard → {output_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--annot_csv",  default=cfg.ANNOT_CSV)
    p.add_argument("--mask_dir",   default=cfg.MASK_DIR)
    p.add_argument("--output_dir", default="./outputs")
    args = p.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    print("\n" + "="*55)
    print("  FETAL BIOMETRY — DATASET EXPLORER")
    print("="*55)

    df = pd.read_csv(args.annot_csv)
    df_full, df_clean, outliers = analyse_annotations(df)

    print("\n  Analysing masks...")
    mask_stats = analyse_masks(args.mask_dir)

    print("\n  Generating annotation dashboard...")
    plot_annotation_dashboard(
        df_full, df_clean,
        os.path.join(args.output_dir, "annotation_dashboard.png")
    )

    # Save clean split CSVs
    df_clean = df_clean.sample(frac=1, random_state=cfg.RANDOM_SEED).reset_index(drop=True)
    n_val = int(len(df_clean) * cfg.VAL_FRAC)
    df_clean.iloc[n_val:].to_csv(os.path.join(args.output_dir, "train_split.csv"), index=False)
    df_clean.iloc[:n_val].to_csv(os.path.join(args.output_dir, "val_split.csv"),   index=False)
    print(f"\n  Splits saved: train={len(df_clean)-n_val}  val={n_val}")

    # Save stats JSON
    stats = {
        "total": int(len(df_full)),
        "clean": int(len(df_clean)),
        "outliers": int(len(outliers)),
        "BPD_mean_px": float(df_clean.BPD_dist.mean()),
        "OFD_mean_px": float(df_clean.OFD_dist.mean()),
        "ratio_median": float(df_clean.ratio.median()),
    }
    if mask_stats:
        stats["mask_n"]          = mask_stats["n_masks"]
        stats["mask_fg_pct"]     = float(mask_stats["areas"].mean()/(540*800)*100)
        stats["mask_area_mean"]  = float(mask_stats["areas"].mean())
    with open(os.path.join(args.output_dir, "dataset_stats.json"), "w") as f:
        import json; json.dump(stats, f, indent=2)
    print(f"  Stats saved: {args.output_dir}/dataset_stats.json")
    print("\n✓ Exploration complete. Ready to train.")


if __name__ == "__main__":
    main()
